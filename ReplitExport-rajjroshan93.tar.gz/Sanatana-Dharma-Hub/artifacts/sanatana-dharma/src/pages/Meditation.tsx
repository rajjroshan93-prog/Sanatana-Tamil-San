import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { mantras } from '../data/content';
import { Play, Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';

function createOmTone(ctx: AudioContext, vol: number): () => void {
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();
  const gain = ctx.createGain();

  osc1.type = 'sine';
  osc1.frequency.setValueAtTime(136.1, ctx.currentTime); // Om frequency
  osc2.type = 'sine';
  osc2.frequency.setValueAtTime(272.2, ctx.currentTime); // Overtone
  gain.gain.setValueAtTime(0, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(vol * 0.25, ctx.currentTime + 2);

  osc1.connect(gain);
  osc2.connect(gain);
  gain.connect(ctx.destination);
  osc1.start();
  osc2.start();

  return () => {
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1.5);
    setTimeout(() => {
      try { osc1.stop(); osc2.stop(); } catch {}
    }, 1600);
  };
}

export default function Meditation() {
  const [isActive, setIsActive] = useState(false);
  const [time, setTime] = useState(0);
  const [mantraIndex, setMantraIndex] = useState(0);
  const [audioOn, setAudioOn] = useState(false);
  const [audioReady, setAudioReady] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const stopToneRef = useRef<(() => void) | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const stopTone = useCallback(() => {
    if (stopToneRef.current) {
      stopToneRef.current();
      stopToneRef.current = null;
    }
  }, []);

  const startTone = useCallback(() => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') ctx.resume();
    stopTone();
    stopToneRef.current = createOmTone(ctx, 0.8);
  }, [stopTone]);

  useEffect(() => {
    setAudioReady(typeof window !== 'undefined' && 'AudioContext' in window);
  }, []);

  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setTime(t => {
          if (t > 0 && (t + 1) % 15 === 0) {
            setMantraIndex(i => (i + 1) % mantras.length);
          }
          return t + 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isActive]);

  useEffect(() => {
    if (audioOn && isActive) {
      startTone();
    } else {
      stopTone();
    }
  }, [audioOn, isActive, startTone, stopTone]);

  useEffect(() => {
    return () => { stopTone(); audioCtxRef.current?.close(); };
  }, []);

  const toggleTimer = () => setIsActive(a => !a);

  const resetTimer = () => {
    setIsActive(false);
    setTime(0);
    setMantraIndex(0);
    stopTone();
  };

  const toggleAudio = () => {
    setAudioOn(a => !a);
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const breathPhase = isActive ? Math.floor((time % 8) / 4) === 0 ? 'Breathe In' : 'Breathe Out' : 'Begin';

  return (
    <div className="min-h-screen bg-[#06050f] text-white flex flex-col items-center justify-center p-6 relative overflow-hidden select-none">
      {/* Deep ambient background */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <motion.div
          animate={{
            opacity: isActive ? [0.25, 0.55, 0.25] : 0.18,
            scale: isActive ? [1, 1.15, 1] : 1
          }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute inset-0"
          style={{ background: 'radial-gradient(circle at 50% 45%, rgba(123,47,190,0.18) 0%, transparent 65%)' }}
        />
        <motion.div
          animate={{ opacity: isActive ? [0.1, 0.3, 0.1] : 0.08 }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
          className="absolute inset-0"
          style={{ background: 'radial-gradient(circle at 50% 45%, rgba(255,107,53,0.12) 0%, transparent 55%)' }}
        />
      </div>

      <div className="relative z-10 w-full max-w-sm flex flex-col items-center gap-8 md:gap-10">
        {/* Breathing Circle */}
        <div className="relative w-56 h-56 md:w-64 md:h-64 flex items-center justify-center">
          <motion.div
            animate={isActive ? { scale: [1, 1.45, 1], opacity: [0.2, 0.5, 0.2] } : { scale: 1, opacity: 0.15 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute inset-0 rounded-full"
            style={{ border: '1.5px solid rgba(123,47,190,0.5)', boxShadow: '0 0 60px rgba(123,47,190,0.25)' }}
          />
          <motion.div
            animate={isActive ? { scale: [1, 1.28, 1], opacity: [0.4, 0.9, 0.4] } : { scale: 1, opacity: 0.35 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
            className="absolute w-44 h-44 md:w-48 md:h-48 rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(123,47,190,0.18) 0%, rgba(255,107,53,0.08) 70%, transparent 100%)',
              border: '1px solid rgba(255,255,255,0.07)',
              backdropFilter: 'blur(4px)'
            }}
          />
          <div className="z-10 flex flex-col items-center gap-1">
            <span className="text-4xl md:text-5xl font-mono font-light tracking-widest">{formatTime(time)}</span>
            {isActive && (
              <motion.span
                key={breathPhase}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs tracking-[0.25em] uppercase text-white/40 font-cinzel"
              >
                {breathPhase}
              </motion.span>
            )}
          </div>
        </div>

        {/* Mantra Display */}
        <div className="h-28 flex items-center justify-center text-center w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={mantraIndex}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.8 }}
              className="px-2"
            >
              <p className="text-xs font-cinzel tracking-[0.3em] text-orange-400/60 uppercase mb-3">
                {mantras[mantraIndex].title} · {mantras[mantraIndex].deity}
              </p>
              <p className="text-lg md:text-xl font-cinzel text-white/75 leading-loose whitespace-pre-line">
                {mantras[mantraIndex].text}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-5">
          <button
            onClick={resetTimer}
            className="p-2.5 rounded-full text-white/30 hover:text-white/70 hover:bg-white/8 transition-all"
            title="Reset"
          >
            <RotateCcw size={20} />
          </button>

          <button
            onClick={toggleTimer}
            className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-xl"
          >
            {isActive ? <Pause size={22} fill="black" /> : <Play size={22} fill="black" className="ml-1" />}
          </button>

          {audioReady && (
            <button
              onClick={toggleAudio}
              className={`p-2.5 rounded-full transition-all ${audioOn ? 'text-orange-400 bg-orange-500/15' : 'text-white/30 hover:text-white/70 hover:bg-white/8'}`}
              title={audioOn ? 'Mute Om tone' : 'Play 136Hz Om tone'}
            >
              {audioOn ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </button>
          )}
        </div>

        {/* Audio hint */}
        {audioReady && (
          <p className="text-xs text-white/20 text-center -mt-4">
            {audioOn ? '136Hz Om frequency playing' : 'Tap speaker for sacred Om tone'}
          </p>
        )}
      </div>
    </div>
  );
}
