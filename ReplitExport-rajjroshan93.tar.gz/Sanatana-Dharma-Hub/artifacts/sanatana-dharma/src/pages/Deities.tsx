import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { deities } from '../data/content';
import { Link } from 'wouter';

function DeityCard({ deity, index }: { deity: typeof deities[0]; index: number }) {
  const [imgError, setImgError] = useState(false);

  return (
    <Link href={`/deity/${deity.id}`}>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.07 }}
        className="group glass-panel rounded-2xl overflow-hidden cursor-pointer h-[380px] relative border border-card-border/40 hover:border-primary/40 transition-all duration-500 hover:shadow-xl"
        style={{ '--deity-glow': deity.glowColor } as React.CSSProperties}
        data-testid={`deity-card-${deity.id}`}
      >
        {/* Background image or fallback gradient */}
        <div className="absolute inset-0">
          {!imgError ? (
            <img
              src={deity.image}
              alt={deity.name}
              className="w-full h-full object-cover object-top opacity-55 group-hover:opacity-90 group-hover:scale-105 transition-all duration-700 ease-out"
              onError={() => setImgError(true)}
            />
          ) : (
            <div
              className={`w-full h-full bg-gradient-to-br ${deity.fallbackGradient} opacity-70 group-hover:opacity-90 transition-opacity duration-500`}
            />
          )}
        </div>

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/55 to-black/10" />

        {/* Deity glow on hover */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at 50% 80%, ${deity.glowColor} 0%, transparent 65%)` }}
        />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <p
            className="text-xs font-cinzel tracking-[0.2em] uppercase mb-2 opacity-70"
            style={{ color: deity.accentColor }}
          >
            {deity.mantra}
          </p>
          <h3
            className="text-3xl font-cinzel font-bold mb-1.5 drop-shadow-md transition-colors duration-300"
            style={{ color: deity.accentColor }}
          >
            {deity.name}
          </h3>
          <p className="text-sm text-white/60 mb-3">{deity.title}</p>
          <div className="overflow-hidden max-h-0 group-hover:max-h-12 transition-all duration-300">
            <p className="text-xs text-white/50 line-clamp-2">{deity.description}</p>
          </div>
          <div
            className="inline-flex items-center gap-1.5 mt-3 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            style={{ color: deity.accentColor }}
          >
            Explore
            <span>→</span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export default function Deities() {
  return (
    <div className="p-5 md:p-10 max-w-7xl mx-auto mt-16 md:mt-0 pb-24">
      <header className="mb-10 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold text-gradient-saffron mb-3">
          Divine Pantheon
        </h1>
        <p className="text-muted-foreground max-w-2xl">
          Explore the divine manifestations of the Supreme. Each deity represents a different aspect of ultimate reality, guiding devotees on their spiritual journey.
        </p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {deities.map((deity, index) => (
          <DeityCard key={deity.id} deity={deity} index={index} />
        ))}
      </div>
    </div>
  );
}
