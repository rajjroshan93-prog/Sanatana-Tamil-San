import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { deities } from '../data/content';
import { motion } from 'framer-motion';
import { ArrowLeft, Volume2, VolumeX } from 'lucide-react';

export default function DeityDetail() {
  const [, params] = useRoute('/deity/:id');
  const deity = deities.find(d => d.id === params?.id);
  const [imgError, setImgError] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  if (!deity) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        Deity not found. <Link href="/deities"><span className="text-primary underline ml-2">Go back</span></Link>
      </div>
    );
  }

  const speakMantra = () => {
    if (!('speechSynthesis' in window)) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const utterance = new SpeechSynthesisUtterance(deity.mantra);
    utterance.rate = 0.7;
    utterance.pitch = 0.8;
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  return (
    <div className="min-h-screen text-foreground relative overflow-hidden">
      {/* Background Image with overlay */}
      <div className="absolute inset-0 z-0">
        {!imgError ? (
          <img
            src={deity.image}
            alt={deity.name}
            className="w-full h-full object-cover"
            style={{ filter: 'brightness(0.22) saturate(1.3)' }}
            onError={() => setImgError(true)}
          />
        ) : (
          <div className={`w-full h-full bg-gradient-to-br ${deity.fallbackGradient}`} />
        )}
        {/* Gradient overlays for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/10 to-background" />
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(ellipse at 50% 30%, ${deity.glowColor} 0%, transparent 65%)`
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 p-5 md:p-12 max-w-5xl mx-auto pt-20 md:pt-10 pb-32 md:pb-20">
        <Link href="/deities">
          <button className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-8 glass-panel px-4 py-2 rounded-full text-sm">
            <ArrowLeft size={15} /> Back to Pantheon
          </button>
        </Link>

        <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          {/* Hero */}
          <div className="mb-10">
            <h1
              className="text-5xl md:text-8xl font-cinzel font-bold mb-3 drop-shadow-2xl"
              style={{ color: deity.accentColor, textShadow: `0 0 40px ${deity.glowColor}` }}
            >
              {deity.name}
            </h1>
            <h2 className="text-lg md:text-2xl font-cinzel text-white/70 tracking-wider">{deity.title}</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* Deity image card (separate visual) */}
            <div className="space-y-6">
              {/* Deity portrait */}
              <div
                className="glass-panel rounded-2xl overflow-hidden border aspect-[3/4] relative flex items-center justify-center"
                style={{ borderColor: `${deity.accentColor}30` }}
              >
                {!imgError ? (
                  <img
                    src={deity.image}
                    alt={deity.name}
                    className="w-full h-full object-cover object-top"
                    onError={() => setImgError(true)}
                  />
                ) : (
                  <div
                    className={`w-full h-full bg-gradient-to-br ${deity.fallbackGradient} flex items-center justify-center`}
                  >
                    <span className="text-8xl font-cinzel" style={{ color: deity.accentColor }}>
                      {deity.name[0]}
                    </span>
                  </div>
                )}
                <div
                  className="absolute inset-0"
                  style={{ background: `linear-gradient(to top, rgba(6,5,15,0.8) 0%, transparent 60%)` }}
                />
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-xs font-cinzel tracking-widest text-white/50 uppercase">
                    {deity.festivals?.join(' · ')}
                  </p>
                </div>
              </div>

              {/* Divine Attributes */}
              <div className="glass-panel p-5 rounded-2xl" style={{ borderColor: `${deity.accentColor}20` }}>
                <h3 className="text-sm font-bold font-cinzel mb-4 tracking-widest uppercase" style={{ color: deity.accentColor }}>
                  Divine Attributes
                </h3>
                <div className="flex flex-wrap gap-2">
                  {deity.attributes.map((attr, i) => (
                    <span
                      key={i}
                      className="text-xs px-3 py-1.5 rounded-full text-white/70 border"
                      style={{ borderColor: `${deity.accentColor}25`, background: `${deity.accentColor}10` }}
                    >
                      {attr}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right column */}
            <div className="space-y-6">
              {/* Sacred Mantra */}
              <motion.div
                className="glass-panel p-6 rounded-2xl relative overflow-hidden"
                style={{ borderColor: `${deity.accentColor}30` }}
                whileHover={{ scale: 1.01 }}
                transition={{ duration: 0.2 }}
              >
                <div
                  className="absolute inset-0 opacity-5"
                  style={{ background: `radial-gradient(circle at 80% 50%, ${deity.accentColor}, transparent)` }}
                />
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold font-cinzel tracking-widest uppercase" style={{ color: deity.accentColor }}>
                    Sacred Mantra
                  </h3>
                  {'speechSynthesis' in window && (
                    <button
                      onClick={speakMantra}
                      className="p-2 rounded-full transition-all hover:scale-110"
                      style={{ background: `${deity.accentColor}20`, color: deity.accentColor }}
                      title={speaking ? 'Stop' : 'Listen to mantra'}
                    >
                      {speaking ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>
                  )}
                </div>
                <div
                  className="rounded-xl p-5 text-center"
                  style={{ background: `${deity.accentColor}08`, border: `1px solid ${deity.accentColor}20` }}
                >
                  <p className="font-cinzel text-lg leading-loose text-white/90 whitespace-pre-line">
                    {deity.mantraFull || deity.mantra}
                  </p>
                </div>
              </motion.div>

              {/* Divine Essence */}
              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden" style={{ borderColor: `${deity.accentColor}20` }}>
                <div className="absolute -top-8 -right-8 text-8xl opacity-5 font-cinzel pointer-events-none select-none">ॐ</div>
                <h3 className="text-sm font-bold font-cinzel mb-4 tracking-widest uppercase" style={{ color: deity.accentColor }}>
                  Divine Essence
                </h3>
                <p className="text-white/70 leading-relaxed text-sm md:text-base">
                  {deity.description}
                </p>
              </div>

              {/* Mythology */}
              <div className="glass-panel p-6 rounded-2xl" style={{ borderColor: `${deity.accentColor}20` }}>
                <h3 className="text-sm font-bold font-cinzel mb-4 tracking-widest uppercase" style={{ color: deity.accentColor }}>
                  Sacred Mythology
                </h3>
                <p className="text-white/70 leading-relaxed text-sm md:text-base">
                  {deity.mythology}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
