import React from 'react';
import { Link } from 'wouter';
import { useAuth } from '../hooks/use-auth';
import { useLocation } from 'wouter';

export default function Home() {
  const { user, signIn, loading } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogin = async () => {
    try {
      await signIn();
      setLocation('/dashboard');
    } catch {}
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Static gradient background — no canvas, no heavy JS */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at 50% 30%, rgba(123,47,190,0.18) 0%, transparent 55%), radial-gradient(ellipse at 80% 80%, rgba(255,107,53,0.1) 0%, transparent 50%), #06050f'
          }}
        />
        {/* Subtle static particles via CSS — no canvas animation */}
        <div className="absolute inset-0 opacity-30" style={{
          backgroundImage: 'radial-gradient(circle, rgba(255,215,0,0.6) 1px, transparent 1px)',
          backgroundSize: '80px 80px'
        }} />
      </div>

      <div className="relative z-10 text-center px-5 max-w-xl mx-auto">
        {/* Om symbol */}
        <div className="mb-6 relative inline-block">
          <div
            className="absolute inset-0 rounded-full"
            style={{ background: 'rgba(255,107,53,0.15)', filter: 'blur(40px)' }}
          />
          <h1
            className="text-8xl md:text-9xl font-cinzel leading-none relative"
            style={{
              background: 'linear-gradient(180deg, #FFD700 0%, #FF6B35 60%, #B5835A 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              filter: 'drop-shadow(0 0 12px rgba(255,215,0,0.35))'
            }}
          >
            ॐ
          </h1>
        </div>

        <h2
          className="text-4xl md:text-5xl font-cinzel font-bold mb-4"
          style={{
            background: 'linear-gradient(90deg, #FF6B35, #FFD700)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text'
          }}
        >
          Sanatana Dharma
        </h2>

        <p className="text-base text-white/55 mb-10 max-w-md mx-auto leading-relaxed">
          A sacred digital sanctuary. Deepen your connection with Vedic tradition and ancient wisdom.
        </p>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
          {user ? (
            <Link href="/dashboard">
              <button
                className="w-full sm:w-auto px-8 py-3.5 rounded-full font-cinzel font-bold text-white text-base"
                style={{
                  background: 'linear-gradient(135deg, #FF6B35, #7B2FBE)',
                  boxShadow: '0 0 28px rgba(255,107,53,0.35)'
                }}
                data-testid="button-enter-sanctuary"
              >
                Enter Sanctuary
              </button>
            </Link>
          ) : (
            <>
              {/* Google login — prominent on homepage */}
              <button
                onClick={handleLogin}
                disabled={loading}
                className="w-full sm:w-auto flex items-center justify-center gap-3 px-7 py-3.5 rounded-full font-bold text-white text-base transition-all active:scale-95 disabled:opacity-60"
                style={{
                  background: 'linear-gradient(135deg, #FF6B35, #7B2FBE)',
                  boxShadow: '0 0 28px rgba(255,107,53,0.35)'
                }}
                data-testid="button-home-login"
              >
                {loading ? (
                  <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                ) : (
                  <img
                    src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                    alt=""
                    className="w-5 h-5 bg-white rounded-full p-0.5"
                  />
                )}
                {loading ? 'Signing in…' : 'Sign in with Google'}
              </button>

              {/* Explore without login */}
              <Link href="/deities">
                <button
                  className="w-full sm:w-auto px-7 py-3.5 rounded-full font-cinzel font-bold text-base border border-white/15 text-white/70 hover:text-white hover:border-white/30 transition-all active:scale-95"
                  style={{ background: 'rgba(255,255,255,0.04)' }}
                  data-testid="button-explore"
                >
                  Explore Deities
                </button>
              </Link>
            </>
          )}
        </div>

        {/* Feature pills */}
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {['7 Deities', 'Bhajans', 'Quiz', 'Meditation', 'Sacred Mantras'].map(f => (
            <span
              key={f}
              className="text-xs px-3 py-1 rounded-full text-white/40 border border-white/10"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              {f}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
