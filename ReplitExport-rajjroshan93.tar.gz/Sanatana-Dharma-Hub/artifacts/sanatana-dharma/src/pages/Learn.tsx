import React from 'react';
import { motion } from 'framer-motion';
import { useXP } from '../hooks/use-xp';
import { BookOpen, CheckCircle, Lock } from 'lucide-react';

const lessons = [
  { id: 1, title: 'The Four Purusharthas', desc: 'Dharma, Artha, Kama, Moksha - the goals of human life.', duration: '10 min', completed: true },
  { id: 2, title: 'Introduction to Vedas', desc: 'Understanding the oldest sacred texts of Hinduism.', duration: '15 min', completed: false },
  { id: 3, title: 'The Paths of Yoga', desc: 'Karma, Bhakti, Jnana, and Raja Yoga explained.', duration: '12 min', completed: false },
  { id: 4, title: 'Concept of Karma & Reincarnation', desc: 'How action shapes our destiny across lifetimes.', duration: '20 min', locked: true },
  { id: 5, title: 'The Upanishads', desc: 'The philosophical core of the Vedas.', duration: '18 min', locked: true },
];

export default function Learn() {
  const { addXP } = useXP();

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto mt-16 md:mt-0">
      <header className="mb-12 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold text-gradient-saffron mb-4">
          Wisdom Hub
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl">
          Dive deep into the philosophy, texts, and practices of Sanatana Dharma. Earn XP as you complete modules.
        </p>
      </header>

      <div className="grid gap-4">
        {lessons.map((lesson, idx) => (
          <motion.div 
            key={lesson.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`glass-panel p-6 rounded-2xl border flex items-center gap-6 transition-all ${
              lesson.locked ? 'opacity-50 border-card-border grayscale' : 'border-card-border/50 hover:border-primary/30 cursor-pointer hover:bg-card-border/10'
            }`}
          >
            <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
              lesson.completed ? 'bg-secondary/20 text-secondary' : 
              lesson.locked ? 'bg-card border border-card-border text-muted-foreground' : 'bg-primary/20 text-primary'
            }`}>
              {lesson.completed ? <CheckCircle size={24} /> : 
               lesson.locked ? <Lock size={20} /> : <BookOpen size={24} />}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-bold text-lg font-cinzel text-foreground">{lesson.title}</h3>
                <span className="text-xs font-mono text-muted-foreground bg-card px-2 py-1 rounded">{lesson.duration}</span>
              </div>
              <p className="text-sm text-muted-foreground">{lesson.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
