import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/use-auth';
import { useLocation } from 'wouter';
import { isDemoMode } from '../lib/firebase';

export default function Login() {
  const { user, loading, redirectPending, authError, signIn } = useAuth();
  const [, setLocation] = useLocation();
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState('');
  const [success, setSuccess] = useState(false);

  // Redirect once signed in
  useEffect(() => {
    if (user && !loading) {
      setSuccess(true);
      const t = setTimeout(() => setLocation('/dashboard'), 600);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [user, loading]);

  const handleLogin = async () => {
    setBusy(true);
    setLocalError('');
    try {
      await signIn();
      // For mobile redirect, the page navigates away — nothing more needed here.
      // For popup / demo, user state updates via onAuthStateChanged.
    } catch (err: any) {
      setLocalError(err?.message ?? 'Sign-in failed. Please try again.');
      setBusy(false);
    }
  };

  const errorMsg = localError || authError;

  // While redirect is returning from Google (page just reloaded)
  if (redirectPending) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background">
        <span className="text-4xl font-cinzel" style={{ color: '#FFD700' }}>ॐ</span>
        <p className="text-white/60 text-sm animate-pulse">Completing sign-in…</p>
        <span className="w-6 h-6 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // Brief success flash before redirect
  if (success) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 bg-background">
        <span className="text-4xl" style={{ color: '#FFD700' }}>ॐ</span>
        <p className="text-green-400 text-sm font-medium">Welcome! Entering sanctuary…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-background" />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at 50% 40%, rgba(123,47,190,0.12) 0%, transparent 60%)' }}
      />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at 50% 70%, rgba(255,107,53,0.08) 0%, transparent 50%)' }}
      />

      <div className="glass-panel p-8 md:p-12 rounded-3xl max-w-sm w-full mx-4 z-10 text-center relative overflow-hidden">
        {/* Top gradient bar */}
        <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-primary via-violet-500 to-amber-400" />

        {/* Om symbol */}
        <div
          className="text-6xl mb-5 font-cinzel"
          style={{ color: '#FFD700', textShadow: '0 0 30px rgba(255,215,0,0.35)' }}
        >
          ॐ
        </div>

        <h2 className="text-2xl font-cinzel font-bold text-foreground mb-1.5">Sacred Entrance</h2>
        <p className="text-sm text-muted-foreground mb-7">
          Sign in to save your spiritual progress, earn XP, and track your devotion journey.
        </p>

        {/* Demo mode notice */}
        {isDemoMode && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-400/80 text-left leading-relaxed">
            <span className="font-semibold text-amber-400">Demo Mode</span> — No Firebase keys found.
            Progress is saved locally in this browser. Add{' '}
            <code className="text-amber-300/70 text-xs">VITE_FIREBASE_*</code> secrets to enable real Google Sign-In.
          </div>
        )}

        {/* Error message */}
        {errorMsg && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400/90 text-left leading-relaxed">
            ⚠️ {errorMsg}
          </div>
        )}

        {/* Google login button */}
        <button
          onClick={handleLogin}
          disabled={busy || loading}
          className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-xl font-medium text-foreground transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,107,53,0.3)',
          }}
          data-testid="button-google-login"
        >
          {busy ? (
            <span className="w-5 h-5 border-2 border-primary/40 border-t-primary rounded-full animate-spin flex-shrink-0" />
          ) : (
            <img
              src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
              alt=""
              className="w-5 h-5 flex-shrink-0 bg-white rounded-full p-0.5"
            />
          )}
          <span>
            {busy
              ? 'Redirecting to Google…'
              : isDemoMode
              ? 'Continue as Demo Devotee'
              : 'Continue with Google'}
          </span>
        </button>

        {/* Helpful hint for real Firebase mode */}
        {!isDemoMode && !errorMsg && (
          <p className="mt-4 text-xs text-muted-foreground/50">
            On mobile, you'll be redirected to Google and returned here automatically.
          </p>
        )}

        <div className="mt-6 pt-5 border-t border-card-border/30 text-xs text-muted-foreground/40">
          By entering, you honor the sacred space of this digital sanctuary.
        </div>
      </div>
    </div>
  );
}
