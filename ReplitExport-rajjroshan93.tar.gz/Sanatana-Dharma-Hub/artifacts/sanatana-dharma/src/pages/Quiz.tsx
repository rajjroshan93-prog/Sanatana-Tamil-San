import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { quizQuestions } from '../data/content';
import { useXP } from '../hooks/use-xp';
import { CheckCircle, XCircle, Award, ArrowRight } from 'lucide-react';

export default function Quiz() {
  const { addXP } = useXP();
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);

  const question = quizQuestions[currentQIndex];

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    
    if (index === question.correctAnswer) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentQIndex < quizQuestions.length - 1) {
      setCurrentQIndex(currentQIndex + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResults(true);
      // Award XP based on score (10 XP per correct answer)
      if (score > 0) {
        addXP(score * 10, 'quiz');
      }
    }
  };

  const resetQuiz = () => {
    setCurrentQIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setShowResults(false);
  };

  return (
    <div className="p-6 md:p-10 max-w-3xl mx-auto mt-16 md:mt-0 min-h-[80vh] flex flex-col justify-center">
      
      {!showResults ? (
        <motion.div 
          key="quiz"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-panel p-8 md:p-12 rounded-3xl"
        >
          <div className="flex justify-between items-center mb-8 text-sm font-bold text-muted-foreground">
            <span>Question {currentQIndex + 1} of {quizQuestions.length}</span>
            <span className="text-secondary font-cinzel">Score: {score}</span>
          </div>

          <h2 className="text-2xl md:text-3xl font-cinzel font-bold text-foreground mb-8 leading-relaxed">
            {question.question}
          </h2>

          <div className="space-y-4">
            {question.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === question.correctAnswer;
              
              let btnClass = "glass-panel p-5 text-left rounded-xl border w-full transition-all text-lg flex items-center justify-between";
              
              if (!isAnswered) {
                btnClass += " border-card-border hover:border-primary/50 hover:bg-primary/5";
              } else if (isCorrect) {
                btnClass += " border-green-500/50 bg-green-500/10 text-green-400";
              } else if (isSelected && !isCorrect) {
                btnClass += " border-destructive/50 bg-destructive/10 text-destructive";
              } else {
                btnClass += " border-card-border opacity-50";
              }

              return (
                <button 
                  key={idx} 
                  onClick={() => handleSelect(idx)}
                  disabled={isAnswered}
                  className={btnClass}
                >
                  <span>{option}</span>
                  {isAnswered && isCorrect && <CheckCircle size={20} className="text-green-500" />}
                  {isAnswered && isSelected && !isCorrect && <XCircle size={20} className="text-destructive" />}
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 flex justify-end"
            >
              <button 
                onClick={handleNext}
                className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-full font-bold hover:shadow-[0_0_20px_rgba(255,107,53,0.4)] transition-shadow"
              >
                {currentQIndex < quizQuestions.length - 1 ? 'Next Question' : 'View Results'} <ArrowRight size={18} />
              </button>
            </motion.div>
          )}
        </motion.div>
      ) : (
        <motion.div 
          key="results"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-panel p-10 md:p-16 rounded-3xl text-center"
        >
          <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-primary/30">
            <Award size={48} className="text-primary" />
          </div>
          <h2 className="text-4xl font-cinzel font-bold text-gradient-gold mb-2">Quiz Completed!</h2>
          <p className="text-xl text-muted-foreground mb-8">You answered {score} out of {quizQuestions.length} correctly.</p>
          
          <div className="inline-block p-6 bg-card/50 rounded-2xl border border-card-border mb-8">
            <div className="text-sm text-secondary font-bold uppercase tracking-wider mb-2">XP Earned</div>
            <div className="text-5xl font-cinzel font-bold text-foreground">+{score * 10}</div>
          </div>

          <div>
            <button 
              onClick={resetQuiz}
              className="px-8 py-4 bg-card border border-primary/50 text-foreground rounded-full font-bold hover:bg-primary/10 transition-colors"
            >
              Take Another Quiz
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
