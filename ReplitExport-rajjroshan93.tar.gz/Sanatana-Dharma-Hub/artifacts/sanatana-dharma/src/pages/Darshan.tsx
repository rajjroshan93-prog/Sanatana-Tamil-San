import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useXP } from '../hooks/use-xp';
import { deities } from '../data/content';
import { Flame, Star, CheckCircle } from 'lucide-react';

export default function Darshan() {
  const { addXP, stats } = useXP();
  const [darshanCompleted, setDarshanCompleted] = useState(false);
  const todayDeity = deities[new Date().getDay() % deities.length];

  const handleComplete = () => {
    if (!darshanCompleted) {
      addXP(5, 'darshan');
      setDarshanCompleted(true);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative flex items-center justify-center p-6">
      <div className="absolute inset-0 z-0">
        <img 
          src={todayDeity.image} 
          alt={todayDeity.name} 
          className="w-full h-full object-cover opacity-20 mix-blend-luminosity" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 glass-panel max-w-2xl w-full rounded-3xl overflow-hidden border border-primary/20"
      >
        <div className="relative h-64 md:h-96 w-full">
          <img 
            src={todayDeity.image} 
            alt={todayDeity.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6 text-center">
            <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-2">Today's Darshan</h2>
            <h1 className="text-4xl md:text-5xl font-cinzel font-bold text-white drop-shadow-lg">{todayDeity.name}</h1>
          </div>
        </div>

        <div className="p-8 md:p-12 text-center">
          <p className="text-lg text-muted-foreground italic mb-8 font-cinzel">
            "{todayDeity.description}"
          </p>

          <div className="p-6 bg-card/40 rounded-2xl border border-card-border mb-8">
            <h3 className="text-sm text-secondary font-bold uppercase tracking-wider mb-3">Sacred Mantra</h3>
            <p className="text-xl font-cinzel text-foreground">{todayDeity.mantra}</p>
          </div>

          <AnimatePresence mode="wait">
            {!darshanCompleted ? (
              <motion.button
                key="btn"
                exit={{ opacity: 0, scale: 0.8 }}
                onClick={handleComplete}
                className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-white rounded-full font-bold shadow-[0_0_20px_rgba(255,107,53,0.3)] hover:shadow-[0_0_30px_rgba(255,107,53,0.5)] transition-all"
              >
                <Flame size={20} /> Complete Daily Darshan
              </motion.button>
            ) : (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="inline-flex items-center gap-3 px-8 py-4 bg-secondary/10 border border-secondary/30 text-secondary rounded-full font-bold"
              >
                <CheckCircle size={20} /> Darshan Completed (+5 XP)
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
