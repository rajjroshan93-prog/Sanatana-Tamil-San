import React from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../hooks/use-auth';
import { useXP } from '../hooks/use-xp';
import { Link } from 'wouter';
import { deities } from '../data/content';

export default function Dashboard() {
  const { user } = useAuth();
  const { stats, level } = useXP();
  
  const todayDeity = deities[new Date().getDay() % deities.length];

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto mt-16 md:mt-0">
      <header className="mb-10">
        <h1 className="text-3xl font-cinzel font-bold text-gradient-saffron">
          Namaste, {user?.displayName?.split(' ')[0] || 'Seeker'}
        </h1>
        <p className="text-muted-foreground mt-2">Welcome back to your spiritual sanctuary.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Progress Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel p-6 rounded-2xl md:col-span-2 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <span className="text-8xl font-cinzel">ॐ</span>
          </div>
          <h2 className="text-xl font-cinzel font-bold mb-4 text-foreground">Spiritual Progress</h2>
          <div className="flex items-end gap-4 mb-2">
            <div className="text-4xl font-bold text-gradient-gold">{level}</div>
            <div className="text-muted-foreground pb-1">{stats?.xp || 0} XP</div>
          </div>
          
          <div className="w-full h-3 bg-card-border/50 rounded-full overflow-hidden mt-4">
            <div className="h-full bg-gradient-to-r from-primary to-accent w-1/3 rounded-full" />
          </div>
          
          <div className="flex gap-4 mt-6">
            <div className="bg-card/50 px-4 py-2 rounded-lg border border-card-border">
              <div className="text-xs text-muted-foreground mb-1">Streak</div>
              <div className="font-bold text-primary">{stats?.streak || 0} Days</div>
            </div>
            <div className="bg-card/50 px-4 py-2 rounded-lg border border-card-border">
              <div className="text-xs text-muted-foreground mb-1">Lessons</div>
              <div className="font-bold text-primary">{stats?.lessonsCompleted || 0}</div>
            </div>
          </div>
        </motion.div>

        {/* Daily Darshan */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-panel p-0 rounded-2xl overflow-hidden group relative"
        >
          <img src={todayDeity.image} alt={todayDeity.name} className="w-full h-48 object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-500" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="text-xs text-primary font-bold uppercase tracking-wider mb-1">Daily Darshan</div>
            <h3 className="text-2xl font-cinzel font-bold text-foreground mb-1">{todayDeity.name}</h3>
            <p className="text-sm text-muted-foreground line-clamp-1">{todayDeity.title}</p>
          </div>
          <Link href={`/deity/${todayDeity.id}`} className="absolute inset-0 z-10" />
        </motion.div>
      </div>
    </div>
  );
}
