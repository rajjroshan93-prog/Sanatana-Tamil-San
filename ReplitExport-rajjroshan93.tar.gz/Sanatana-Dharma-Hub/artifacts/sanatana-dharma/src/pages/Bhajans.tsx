import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { bhajans } from '../data/content';
import { useBhajanPlayer } from '../hooks/use-bhajan-player';
import { Play, Pause, Music } from 'lucide-react';

export default function Bhajans() {
  const { currentBhajan, isPlaying, play, pause, resume, setPlaylist } = useBhajanPlayer();

  useEffect(() => {
    setPlaylist(bhajans);
  }, [setPlaylist]);

  return (
    <div className="p-5 md:p-10 max-w-5xl mx-auto mt-16 md:mt-0 pb-40 md:pb-20">
      <header className="mb-10 text-center md:text-left">
        <div className="flex items-center gap-3 mb-4 justify-center md:justify-start">
          <Music size={20} className="text-primary" />
          <span className="text-xs font-cinzel tracking-widest text-muted-foreground uppercase">Sacred Sound</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold text-gradient-saffron mb-3">
          Bhajan Mandal
        </h1>
        <p className="text-muted-foreground max-w-xl">
          Immerse yourself in devotional bhajans and kirtans. Music auto-plays through the floating player below.
        </p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {bhajans.map((bhajan, i) => {
          const isCurrent = currentBhajan?.id === bhajan.id;

          return (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              key={bhajan.id}
              className={`glass-panel rounded-2xl overflow-hidden group border transition-all cursor-pointer ${
                isCurrent
                  ? 'border-primary/50 shadow-[0_0_24px_rgba(255,107,53,0.15)]'
                  : 'border-card-border/40 hover:border-primary/25'
              }`}
              onClick={() => {
                if (isCurrent && isPlaying) pause();
                else if (isCurrent) resume();
                else play(bhajan, bhajans);
              }}
              data-testid={`bhajan-card-${bhajan.id}`}
            >
              {/* Image */}
              <div className="relative h-44 w-full overflow-hidden">
                <img
                  src={bhajan.image}
                  alt={bhajan.title}
                  className={`w-full h-full object-cover object-top transition-transform duration-700 ${isCurrent ? 'scale-105' : 'group-hover:scale-105'}`}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                {/* Play button */}
                <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center shadow-xl transition-all ${isCurrent && isPlaying ? 'bg-primary scale-100' : 'bg-white/20 backdrop-blur-md scale-90 group-hover:scale-100'}`}>
                    {isCurrent && isPlaying
                      ? <Pause size={22} fill="white" className="text-white" />
                      : <Play size={22} fill="white" className="text-white ml-1" />
                    }
                  </div>
                </div>

                {/* Deity tag */}
                <div className="absolute top-3 right-3">
                  <span className="text-xs px-2.5 py-1 rounded-full text-white/80 font-medium" style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)' }}>
                    {bhajan.deity}
                  </span>
                </div>
              </div>

              {/* Info */}
              <div className="p-4 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-base text-foreground truncate font-cinzel">{bhajan.title}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{bhajan.artist}</p>
                </div>

                {/* Playing indicator */}
                {isCurrent && isPlaying && (
                  <div className="flex items-end gap-0.5 h-5 flex-shrink-0">
                    {[0.8, 0.5, 0.9].map((delay, idx) => (
                      <motion.div
                        key={idx}
                        animate={{ scaleY: [0.4, 1, 0.4] }}
                        transition={{ repeat: Infinity, duration: delay, delay: idx * 0.15 }}
                        className="w-1 bg-primary rounded-t origin-bottom"
                        style={{ height: 16 }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-8 p-4 glass-panel rounded-xl border border-card-border/30 text-center">
        <p className="text-xs text-muted-foreground">
          Audio streams from the Internet Archive. If a track does not play, the player will offer a YouTube fallback automatically.
        </p>
      </div>
    </div>
  );
}
