import React from 'react';
import { useAuth } from '../hooks/use-auth';
import { useXP, getLevel } from '../hooks/use-xp';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';

export default function Profile() {
  const { user, signOut } = useAuth();
  const { stats, level } = useXP();
  const [, setLocation] = useLocation();

  if (!user) {
    setLocation('/login');
    return null;
  }

  // Calculate next level
  const levels = [
    { name: 'Shishya', min: 0 },
    { name: 'Sadhak', min: 100 },
    { name: 'Yogi', min: 300 },
    { name: 'Acharya', min: 700 },
    { name: 'Guru', min: 1500 },
    { name: 'Maharishi', min: 3000 }
  ];

  let nextLevel = levels[levels.length - 1];
  let currentLevelObj = levels[0];
  let currentLevelNum = 1;

  for (let i = 0; i < levels.length - 1; i++) {
    if (stats.xp >= levels[i].min && stats.xp < levels[i + 1].min) {
      currentLevelObj = levels[i];
      nextLevel = levels[i + 1];
      currentLevelNum = i + 1;
      break;
    }
  }
  if (stats.xp >= levels[levels.length - 1].min) {
    currentLevelNum = levels.length;
  }

  const progress = Math.min(100, Math.max(0, ((stats.xp - currentLevelObj.min) / (nextLevel.min - currentLevelObj.min)) * 100));

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto mt-16 md:mt-0">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel p-8 rounded-3xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px]" />
        
        <div className="flex flex-col md:flex-row items-center md:items-start gap-8 relative z-10">
          <div className="relative">
            <img 
              src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} 
              alt="Avatar" 
              className="w-32 h-32 rounded-full border-4 border-card-border p-1 object-cover"
            />
            <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-bold border-2 border-background shadow-lg">
              {currentLevelNum}
            </div>
          </div>
          
          <div className="flex-1 text-center md:text-left w-full">
            <h1 className="text-3xl font-cinzel font-bold text-foreground">{user.displayName}</h1>
            <p className="text-primary mb-6 font-cinzel tracking-widest uppercase text-sm mt-1">{level}</p>
            
            <div className="bg-card/50 p-6 rounded-2xl border border-card-border">
              <div className="flex justify-between text-sm mb-2 font-bold">
                <span className="text-muted-foreground">{stats.xp} XP</span>
                <span className="text-secondary">{nextLevel.min} XP for {nextLevel.name}</span>
              </div>
              <div className="w-full h-4 bg-background rounded-full overflow-hidden mb-2">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
                />
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
        <div className="glass-panel p-6 rounded-2xl text-center">
          <div className="text-3xl font-cinzel font-bold text-gradient-gold mb-1">{stats.streak}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider">Day Streak</div>
        </div>
        <div className="glass-panel p-6 rounded-2xl text-center">
          <div className="text-3xl font-cinzel font-bold text-gradient-saffron mb-1">{stats.quizzesCompleted}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider">Quizzes</div>
        </div>
        <div className="glass-panel p-6 rounded-2xl text-center">
          <div className="text-3xl font-cinzel font-bold text-accent mb-1">{stats.lessonsCompleted}</div>
          <div className="text-xs text-muted-foreground uppercase tracking-wider">Lessons</div>
        </div>
        <div className="glass-panel p-6 rounded-2xl flex items-center justify-center">
          <button onClick={signOut} className="text-destructive font-bold hover:underline">
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
