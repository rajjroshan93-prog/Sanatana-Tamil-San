import React, { useEffect, useRef, useState } from 'react';
import { useBhajanPlayer } from '../hooks/use-bhajan-player';
import { Play, Pause, X, SkipForward, SkipBack, Repeat } from 'lucide-react';

// Android-safe audio player:
// <audio> lives in JSX so the browser knows about it before user gesture.
// play() is called DIRECTLY from onClick — satisfies Android's user-gesture requirement.

export function BhajanPlayer() {
  const {
    currentBhajan, isPlaying, volume, loop,
    pause, resume, stop, next, prev, toggleLoop, setUseYoutube
  } = useBhajanPlayer();

  const audioRef = useRef<HTMLAudioElement>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [audioFailed, setAudioFailed] = useState(false);
  const prevIdRef = useRef<string>('');

  // When bhajan changes, load new source
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !currentBhajan) return;
    if (prevIdRef.current === currentBhajan.id) return;
    prevIdRef.current = currentBhajan.id;
    setAudioFailed(false);
    setProgress(0);
    setDuration(0);
    audio.src = currentBhajan.audioUrl;
    audio.load();
  }, [currentBhajan?.id]);

  // Sync volume
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  // Sync loop
  useEffect(() => {
    if (audioRef.current) audioRef.current.loop = loop;
  }, [loop]);

  // Play/pause: only sync when isPlaying changes (NOT from click — see handlers below)
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || audioFailed) return;
    if (!isPlaying) {
      audio.pause();
    }
    // Don't call audio.play() here — only call from direct user click (Android)
  }, [isPlaying, audioFailed]);

  // DIRECT click handler — satisfies Android user gesture requirement
  const handlePlayPause = () => {
    const audio = audioRef.current;
    if (!audio || !currentBhajan) return;

    if (isPlaying) {
      audio.pause();
      pause();
    } else {
      // This play() call is synchronous in a click handler → Android allows it
      audio.play()
        .then(() => resume())
        .catch(() => {
          setAudioFailed(true);
          setUseYoutube(true);
        });
    }
  };

  const handleNext = () => {
    audioRef.current?.pause();
    next();
    // Small delay so new src is set before play
    setTimeout(() => {
      audioRef.current?.play().catch(() => {});
    }, 150);
  };

  const handlePrev = () => {
    audioRef.current?.pause();
    prev();
    setTimeout(() => {
      audioRef.current?.play().catch(() => {});
    }, 150);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
      setProgress(val);
    }
  };

  const fmt = (s: number) => {
    if (!s || !isFinite(s)) return '0:00';
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  };

  if (!currentBhajan) return null;

  return (
    <>
      {/* Hidden audio element — always in DOM so Android recognises user gesture flow */}
      <audio
        ref={audioRef}
        preload="none"
        onTimeUpdate={() => setProgress(audioRef.current?.currentTime ?? 0)}
        onLoadedMetadata={() => setDuration(audioRef.current?.duration ?? 0)}
        onEnded={() => { if (!loop) handleNext(); }}
        onError={() => { setAudioFailed(true); setUseYoutube(true); }}
      />

      <div className="fixed bottom-16 md:bottom-0 left-0 right-0 z-50">
        <div
          className="border-t border-white/8 px-4 pt-2 pb-3 md:pb-4"
          style={{ background: 'rgba(8,7,18,0.95)', backdropFilter: 'blur(16px)' }}
        >
          {/* Seek bar */}
          {duration > 0 && (
            <div className="mb-2">
              <input
                type="range"
                min={0}
                max={duration}
                value={progress}
                step={0.5}
                onChange={handleSeek}
                className="w-full h-0.5 appearance-none cursor-pointer rounded-full"
                style={{ accentColor: '#FF6B35', background: `linear-gradient(to right, #FF6B35 ${(progress/duration)*100}%, rgba(255,255,255,0.1) 0%)` }}
              />
            </div>
          )}

          <div className="flex items-center gap-3">
            {/* Thumbnail */}
            <img
              src={currentBhajan.image}
              alt={currentBhajan.title}
              className="w-10 h-10 rounded-lg object-cover object-top flex-shrink-0 border border-white/10"
              onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=80'; }}
            />

            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate leading-snug">{currentBhajan.title}</p>
              <p className="text-xs text-white/40 truncate">
                {duration > 0 ? `${fmt(progress)} / ${fmt(duration)}` : currentBhajan.artist}
              </p>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-1 flex-shrink-0">
              <button
                onClick={handlePrev}
                className="p-2 text-white/40 hover:text-white transition-colors rounded-lg"
                aria-label="Previous"
              >
                <SkipBack size={16} />
              </button>

              {/* Play/Pause — must be a direct click, no useEffect chain */}
              <button
                onClick={handlePlayPause}
                className="w-9 h-9 rounded-full flex items-center justify-center text-white flex-shrink-0"
                style={{ background: '#FF6B35' }}
                aria-label={isPlaying ? 'Pause' : 'Play'}
                data-testid="button-play-pause"
              >
                {isPlaying
                  ? <Pause size={15} fill="white" />
                  : <Play size={15} fill="white" className="ml-0.5" />
                }
              </button>

              <button
                onClick={handleNext}
                className="p-2 text-white/40 hover:text-white transition-colors rounded-lg"
                aria-label="Next"
              >
                <SkipForward size={16} />
              </button>

              <button
                onClick={toggleLoop}
                className={`p-2 rounded-lg transition-colors ${loop ? 'text-orange-400' : 'text-white/25 hover:text-white/50'}`}
                aria-label="Loop"
              >
                <Repeat size={14} />
              </button>

              <button
                onClick={stop}
                className="p-2 text-white/25 hover:text-white/70 transition-colors rounded-lg"
                aria-label="Close player"
              >
                <X size={15} />
              </button>
            </div>
          </div>

          {/* Audio failed — show YouTube fallback inline */}
          {audioFailed && (
            <div className="mt-2 rounded-xl overflow-hidden">
              <iframe
                key={currentBhajan.id + '-yt'}
                src={`https://www.youtube.com/embed/${currentBhajan.youtubeId}?autoplay=1&controls=1&rel=0`}
                allow="autoplay; encrypted-media"
                style={{ width: '100%', height: 56, border: 'none' }}
                title={currentBhajan.title}
              />
            </div>
          )}
        </div>
      </div>
    </>
  );
}
