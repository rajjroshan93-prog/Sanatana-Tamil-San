import React, { useEffect, useRef } from 'react';

// Lightweight CSS-only particle background for mobile.
// Canvas-based particle loop is too heavy on low-end Android devices.
// We use simple CSS dot grid + a subtle radial pulse instead.

export function ParticleBackground() {
  // Intentionally empty — replaced by CSS in Home.tsx
  // This component is kept so imports don't break.
  return null;
}
