import React from 'react';
import { Link, useLocation } from 'wouter';
import { Home, BookOpen, Music, PlaySquare, Award, User as UserIcon, Flame, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/use-auth';
import { useXP } from '../../hooks/use-xp';

const navItems = [
  { icon: Home, label: 'Home', href: '/' },
  { icon: Flame, label: 'Darshan', href: '/darshan' },
  { icon: BookOpen, label: 'Deities', href: '/deities' },
  { icon: PlaySquare, label: 'Meditation', href: '/meditation' },
  { icon: Music, label: 'Bhajans', href: '/bhajans' },
  { icon: Award, label: 'Quiz', href: '/quiz' },
  { icon: BookOpen, label: 'Learn', href: '/learn' }
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, signOut } = useAuth();
  const { stats, level } = useXP();

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      {/* Sidebar Desktop */}
      <aside className="hidden md:flex flex-col w-64 glass-panel border-r border-card-border sticky top-0 h-screen z-40">
        <div className="p-6 text-center border-b border-card-border/50">
          <h1 className="text-2xl font-cinzel text-gradient-saffron font-bold">Sanatana</h1>
          <p className="text-sm font-cinzel text-muted-foreground tracking-widest mt-1">DHARMA</p>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 cursor-pointer ${isActive ? 'bg-primary/10 text-primary border border-primary/20 shadow-[0_0_15px_rgba(255,107,53,0.15)]' : 'text-muted-foreground hover:bg-card-border/30 hover:text-foreground'}`}>
                  <item.icon size={20} className={isActive ? "text-primary" : ""} />
                  <span className="font-medium tracking-wide">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {user ? (
          <div className="p-4 border-t border-card-border/50 bg-card/20">
            <Link href="/profile">
              <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-card-border/30 transition-colors cursor-pointer mb-2">
                <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt="Avatar" className="w-10 h-10 rounded-full border border-primary/30" />
                <div className="flex-1 overflow-hidden">
                  <p className="text-sm font-medium truncate">{user.displayName}</p>
                  <p className="text-xs text-primary/80 font-cinzel">{level} • {stats?.xp || 0} XP</p>
                </div>
              </div>
            </Link>
            <button onClick={signOut} className="w-full flex items-center justify-center gap-2 text-xs text-muted-foreground hover:text-destructive transition-colors py-2">
              <LogOut size={14} /> Sign Out
            </button>
          </div>
        ) : (
          <div className="p-4 border-t border-card-border/50">
            <Link href="/login">
              <div className="w-full py-2 rounded bg-primary/10 text-primary border border-primary/20 text-center font-medium hover:bg-primary/20 transition-all cursor-pointer">
                Sign In
              </div>
            </Link>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 pb-20 md:pb-0 min-h-screen relative z-10">
        {children}
      </main>

      {/* Bottom Nav Mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 glass-panel border-t border-card-border z-40 flex justify-around items-center p-2 pb-safe">
        {navItems.slice(0, 4).map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex flex-col items-center p-2 rounded-lg transition-all ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                <item.icon size={22} className={isActive ? "animate-pulse-glow rounded-full" : ""} />
                <span className="text-[10px] mt-1 font-medium">{item.label}</span>
              </div>
            </Link>
          );
        })}
        <Link href={user ? "/profile" : "/login"}>
          <div className={`flex flex-col items-center p-2 rounded-lg transition-all ${location === '/profile' ? 'text-primary' : 'text-muted-foreground'}`}>
            <UserIcon size={22} />
            <span className="text-[10px] mt-1 font-medium">{user ? "Profile" : "Login"}</span>
          </div>
        </Link>
      </nav>
    </div>
  );
}
