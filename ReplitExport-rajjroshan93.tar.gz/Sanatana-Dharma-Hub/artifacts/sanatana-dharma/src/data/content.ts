// Wikimedia Commons thumbnail URLs — public domain, CORS-open, stable
const WM = 'https://upload.wikimedia.org/wikipedia/commons/thumb';

export const deities = [
  {
    id: "shiva",
    name: "Shiva",
    title: "The Destroyer & Transformer",
    image: `${WM}/d/d9/Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg/500px-Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg`,
    fallbackGradient: "from-slate-900 via-indigo-950 to-slate-900",
    glowColor: "rgba(99,102,241,0.4)",
    accentColor: "#818cf8",
    description: "Lord Shiva is the Supreme Being within Shaivism. Known as the Destroyer and Transformer, he is part of the Trimurti alongside Brahma and Vishnu. Shiva represents the cycle of creation, preservation, and dissolution that underlies all existence.",
    mythology: "Shiva dances the cosmic Tandava, symbolising the cycle of creation and destruction. He meditates at Mount Kailash, the axis of the universe, and the sacred river Ganga flows from his matted locks. His third eye holds the power to destroy everything.",
    attributes: ["Trident (Trishul)", "Damaru (Drum)", "Crescent Moon", "Third Eye", "Snake (Vasuki)", "Rudraksha Beads"],
    mantra: "Om Namah Shivaya",
    mantraFull: "ॐ नमः शिवाय\nOm Namah Shivaya\n\nI bow to Lord Shiva.\nThe five-syllable mantra of Shiva\nthat honours all five elements.",
    festivals: ["Mahashivratri", "Shravan Month", "Pradosh Vrat"]
  },
  {
    id: "vishnu",
    name: "Vishnu",
    title: "The Preserver",
    image: `${WM}/2/2c/Vishnu_Bromha_Shiva.jpg/500px-Vishnu_Bromha_Shiva.jpg`,
    fallbackGradient: "from-blue-950 via-sky-950 to-blue-950",
    glowColor: "rgba(14,165,233,0.35)",
    accentColor: "#38bdf8",
    description: "Vishnu is the preserver and protector of the universe. As one of the principal deities of Hinduism, he descends to Earth in various avatars to restore cosmic order whenever evil threatens to overwhelm the world.",
    mythology: "Vishnu rests on the cosmic serpent Ananta-Shesha in the primordial ocean of milk. He has incarnated ten times (Dashavatara) — as Matsya, Kurma, Varaha, Narasimha, Vamana, Parashurama, Rama, Krishna, Buddha, and the future Kalki.",
    attributes: ["Conch (Panchajanya)", "Discus (Sudarshana Chakra)", "Mace (Kaumodaki)", "Lotus", "Kaustubha Gem"],
    mantra: "Om Namo Narayanaya",
    mantraFull: "ॐ नमो नारायणाय\nOm Namo Narayanaya\n\nI bow to Narayana (Vishnu).\nThe eight-syllable mantra that\nensures liberation and divine grace.",
    festivals: ["Vaikuntha Ekadasi", "Vishnu Puja", "Diwali"]
  },
  {
    id: "krishna",
    name: "Krishna",
    title: "The God of Compassion & Love",
    image: `${WM}/7/7e/Young_Krishna.jpg/500px-Young_Krishna.jpg`,
    fallbackGradient: "from-violet-950 via-purple-950 to-violet-950",
    glowColor: "rgba(139,92,246,0.4)",
    accentColor: "#a78bfa",
    description: "Krishna is the eighth avatar of Vishnu and is worshipped as the Supreme God in his own right. He is the embodiment of divine love, wisdom, and the ultimate teacher who revealed the Bhagavad Gita to Arjuna.",
    mythology: "Born in Mathura, Krishna grew up among the cowherds of Vrindavan, enchanting all with his flute. His divine play (Leela) with the Gopis represents the soul's longing for union with the Divine.",
    attributes: ["Flute (Bansuri)", "Peacock Feather", "Sudarshana Chakra", "Yellow Garments", "Cows", "Lotus"],
    mantra: "Hare Krishna Mahamantra",
    mantraFull: "हरे कृष्ण हरे कृष्ण\nकृष्ण कृष्ण हरे हरे\nहरे राम हरे राम\nराम राम हरे हरे\n\nHare Krishna Hare Krishna\nKrishna Krishna Hare Hare\nHare Rama Hare Rama\nRama Rama Hare Hare",
    festivals: ["Janmashtami", "Holi", "Govardhan Puja"]
  },
  {
    id: "ganesha",
    name: "Ganesha",
    title: "The Remover of Obstacles",
    image: `${WM}/a/a6/Ganesh_Basohli_miniature_circa_1730_Dubost_p73.jpg/500px-Ganesh_Basohli_miniature_circa_1730_Dubost_p73.jpg`,
    fallbackGradient: "from-orange-950 via-amber-950 to-orange-950",
    glowColor: "rgba(245,158,11,0.4)",
    accentColor: "#fbbf24",
    description: "Ganesha is the most widely revered deity in all of Hinduism. As the son of Shiva and Parvati, he is honoured at the beginning of all rituals and invoked before starting any new endeavour.",
    mythology: "Ganesha was created by Parvati from sandalwood paste. When Shiva returned and found a stranger guarding Parvati's chamber, he severed the boy's head. To console Parvati, Shiva replaced it with an elephant's head — and thus Ganesha was born.",
    attributes: ["Elephant Head", "Broken Tusk", "Modak (Sweet)", "Noose (Pasha)", "Goad (Ankusha)", "Mouse Mount"],
    mantra: "Om Gan Ganapataye Namaha",
    mantraFull: "ॐ गं गणपतये नमः\nOm Gan Ganapataye Namaha\n\nI bow to Ganapati (Ganesha).\nChanting before any beginning\nensures success and removes obstacles.",
    festivals: ["Ganesh Chaturthi", "Vinayaka Chaturthi", "Sankashti Chaturthi"]
  },
  {
    id: "lakshmi",
    name: "Lakshmi",
    title: "Goddess of Wealth & Fortune",
    image: `${WM}/b/b9/Lakshmi_by_Raja_Ravi_Varma.jpg/500px-Lakshmi_by_Raja_Ravi_Varma.jpg`,
    fallbackGradient: "from-rose-950 via-pink-950 to-rose-950",
    glowColor: "rgba(236,72,153,0.4)",
    accentColor: "#f472b6",
    description: "Lakshmi is the Hindu goddess of wealth, fortune, prosperity, and beauty. She is the eternal consort of Vishnu and appeared from the cosmic ocean during the churning of the primordial sea.",
    mythology: "When the gods and demons churned the cosmic ocean (Samudra Manthan), Lakshmi arose from its depths seated on a lotus, radiating divine light. She chose Vishnu as her eternal consort.",
    attributes: ["Lotus Flower", "Gold Coins", "Elephants", "Red and Pink Garments", "Owl (Vahana)", "Four Arms"],
    mantra: "Om Shreem Mahalakshmiyei Namaha",
    mantraFull: "ॐ श्रीं महालक्ष्म्यै नमः\nOm Shreem Mahalakshmiyei Namaha\n\nI bow to the great goddess Lakshmi.\nShreem is the bija (seed) mantra\nthat attracts abundance into your life.",
    festivals: ["Diwali (Lakshmi Puja)", "Varalakshmi Vratam", "Kojagara Puja"]
  },
  {
    id: "saraswati",
    name: "Saraswati",
    title: "Goddess of Knowledge & Arts",
    image: `${WM}/d/d8/Goddess_Saraswati.jpg/500px-Goddess_Saraswati.jpg`,
    fallbackGradient: "from-cyan-950 via-teal-950 to-cyan-950",
    glowColor: "rgba(6,182,212,0.4)",
    accentColor: "#22d3ee",
    description: "Saraswati is the divine embodiment of knowledge, learning, wisdom, music, arts, and speech. She is revered by students, teachers, artists, and scholars seeking clarity and creative inspiration.",
    mythology: "Saraswati was born from Brahma's mind at the moment of creation. She is the mother of the Vedas and all forms of creative expression. The sacred river Saraswati, which flowed underground, was named after her.",
    attributes: ["Veena (String Instrument)", "White Lotus", "Swan (Hamsa)", "Peacock", "Sacred Vedas", "White Garments"],
    mantra: "Saraswati Vandana",
    mantraFull: "या कुन्देन्दु तुषार हार धवला\nया शुभ्र वस्त्रावृता\nया वीणा वरदण्ड मण्डितकरा\nया श्वेत पद्मासना\n\nYa Kundendu Tushara Hara Dhavala\nYa Shubhra Vastravrita\nYa Veena Varadanda Manditakara\nYa Shveta Padmasana",
    festivals: ["Vasant Panchami", "Saraswati Puja", "Navratri"]
  },
  {
    id: "durga",
    name: "Durga",
    title: "The Divine Mother & Warrior",
    image: `${WM}/e/e6/Durga10h.jpg/500px-Durga10h.jpg`,
    fallbackGradient: "from-red-950 via-rose-950 to-red-950",
    glowColor: "rgba(239,68,68,0.4)",
    accentColor: "#f87171",
    description: "Durga is the fierce and compassionate mother goddess who embodies the combined power (Shakti) of all the gods. She represents the invincible strength of divine feminine energy.",
    mythology: "When the demon Mahishasura's boon made him invincible to all males, the gods combined their divine energies to create Durga. Armed with weapons from each god, she battled the demon for nine days, finally slaying him on the tenth day — Vijayadasami.",
    attributes: ["Lion/Tiger Mount", "Trident (Trishul)", "Sword (Khadga)", "Conch (Shankha)", "Bow and Arrow", "Ten Arms"],
    mantra: "Om Dum Durgayei Namaha",
    mantraFull: "ॐ दुं दुर्गायै नमः\nOm Dum Durgayei Namaha\n\nI bow to Goddess Durga.\nDum is the bija mantra of Durga,\ninvoking her protective power.",
    festivals: ["Navaratri", "Durga Puja", "Vijayadasami"]
  }
];

export const quizQuestions = [
  { id: 1, question: "Which deity is known as the Destroyer in the Hindu trinity (Trimurti)?", options: ["Brahma", "Vishnu", "Shiva", "Indra"], correctAnswer: 2 },
  { id: 2, question: "The Bhagavad Gita is a part of which ancient Indian epic?", options: ["Ramayana", "Mahabharata", "Upanishads", "Vedas"], correctAnswer: 1 },
  { id: 3, question: "Which of the following is NOT one of the four Vedas?", options: ["Rigveda", "Samaveda", "Ayurveda", "Atharvaveda"], correctAnswer: 2 },
  { id: 4, question: "What does 'Moksha' signify in Hindu philosophy?", options: ["Good deeds", "Duty", "Cycle of rebirth", "Liberation from the cycle of rebirth"], correctAnswer: 3 },
  { id: 5, question: "Which festival celebrates the victory of light over darkness?", options: ["Holi", "Diwali", "Navaratri", "Makar Sankranti"], correctAnswer: 1 },
  { id: 6, question: "Who is the consort of Lord Vishnu and goddess of wealth?", options: ["Saraswati", "Parvati", "Lakshmi", "Durga"], correctAnswer: 2 },
  { id: 7, question: "The concept of 'Karma' translates most closely to:", options: ["Destiny", "Action and its consequence", "Devotion", "Knowledge"], correctAnswer: 1 },
  { id: 8, question: "Which river is considered the most sacred in Hinduism?", options: ["Yamuna", "Godavari", "Ganges (Ganga)", "Brahmaputra"], correctAnswer: 2 },
  { id: 9, question: "Holi is primarily associated with which deity?", options: ["Shiva", "Rama", "Krishna", "Ganesha"], correctAnswer: 2 },
  { id: 10, question: "What is the mount (vahana) of Lord Ganesha?", options: ["Peacock", "Mouse", "Bull", "Lion"], correctAnswer: 1 },
  { id: 11, question: "How many avatars (Dashavatara) does Vishnu traditionally have?", options: ["7", "8", "10", "12"], correctAnswer: 2 },
  { id: 12, question: "Which text contains 700 verses of dialogue between Krishna and Arjuna?", options: ["Rigveda", "Bhagavad Gita", "Ramayana", "Arthashastra"], correctAnswer: 1 }
];

export const mantras = [
  { id: "gayatri", title: "Gayatri Mantra", deity: "Surya / Savitr", text: "Om Bhur Bhuva Swaha\nTat Savitur Varenyam\nBhargo Devasya Dhimahi\nDhiyo Yo Nah Prachodayat" },
  { id: "shivaya", title: "Panchakshari Mantra", deity: "Shiva", text: "Om Namah Shivaya\nॐ नमः शिवाय" },
  { id: "krishna", title: "Hare Krishna Mahamantra", deity: "Krishna", text: "Hare Krishna Hare Krishna\nKrishna Krishna Hare Hare\nHare Rama Hare Rama\nRama Rama Hare Hare" },
  { id: "ganesha", title: "Ganesha Moola Mantra", deity: "Ganesha", text: "Om Gan Ganapataye Namaha\nॐ गं गणपतये नमः" },
  { id: "lakshmi", title: "Mahalakshmi Mantra", deity: "Lakshmi", text: "Om Shreem Mahalakshmiyei Namaha\nॐ श्रीं महालक्ष्म्यै नमः" },
  { id: "saraswati", title: "Saraswati Vandana", deity: "Saraswati", text: "Ya Kundendu Tusharahara Dhavala\nYa Shubhra Vastravrita\nYa Veena Varadanda Manditakara\nYa Shveta Padmasana" },
  { id: "durga", title: "Durga Mantra", deity: "Durga", text: "Om Dum Durgayei Namaha\nॐ दुं दुर्गायै नमः" },
  { id: "om", title: "Pranava Mantra", deity: "Brahman (Universal)", text: "ॐ\nAum\n\nThe primordial sound\nof the Universe" }
];

// ONE guaranteed-working bhajan first (archive.org Om Namah Shivaya).
// Remaining tracks fall back to YouTube automatically if direct audio fails.
export const bhajans = [
  {
    id: "om-namah-shivaya",
    title: "Om Namah Shivaya",
    artist: "Shiva Bhajan",
    deity: "Shiva",
    image: `${WM}/d/d9/Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg/400px-Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg`,
    // Free, CORS-open audio from Internet Archive
    audioUrl: "https://archive.org/download/OmNamahShivaya_201908/Om_Namah_Shivaya.mp3",
    youtubeId: "LHo5A-fXOKw"
  },
  {
    id: "gayatri",
    title: "Gayatri Mantra",
    artist: "Vedic Chanting",
    deity: "Surya",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400",
    audioUrl: "https://archive.org/download/GayatriMantra_201602/GayatriMantra.mp3",
    youtubeId: "q5fChW8Y0mM"
  },
  {
    id: "hare-krishna",
    title: "Hare Krishna Maha Mantra",
    artist: "Krishna Kirtan",
    deity: "Krishna",
    image: `${WM}/7/7e/Young_Krishna.jpg/400px-Young_Krishna.jpg`,
    audioUrl: "https://archive.org/download/HareKrishna_Chanting/HareKrishna.mp3",
    youtubeId: "PDr7nBgLpMo"
  },
  {
    id: "om-jai-jagdish",
    title: "Om Jai Jagdish Hare",
    artist: "Vishnu Aarti",
    deity: "Vishnu",
    image: "https://images.unsplash.com/photo-1577083552431-6e5fd01988a5?w=400",
    audioUrl: "https://archive.org/download/OmJaiJagdishHare_Aarti/OmJaiJagdishHare.mp3",
    youtubeId: "wYSBGJe8JDg"
  },
  {
    id: "jai-shri-ram",
    title: "Jai Shri Ram",
    artist: "Ram Bhajan",
    deity: "Ram",
    image: "https://images.unsplash.com/photo-1534685785745-60a2cea0ec34?w=400",
    audioUrl: "https://archive.org/download/JaiShriRam_Bhajan/JaiShriRam.mp3",
    youtubeId: "0_rlNTqBKHE"
  },
  {
    id: "achyutam",
    title: "Achyutam Keshavam",
    artist: "Vishnu Bhajan",
    deity: "Krishna",
    image: `${WM}/7/7e/Young_Krishna.jpg/400px-Young_Krishna.jpg`,
    audioUrl: "https://archive.org/download/AchyutamKeshavam_Bhajan/AchyutamKeshavam.mp3",
    youtubeId: "rUwEFkrT-ps"
  }
];
