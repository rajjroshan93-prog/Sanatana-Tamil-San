import { create } from 'zustand';

export interface Bhajan {
  id: string;
  title: string;
  artist: string;
  deity: string;
  image: string;
  audioUrl: string;
  youtubeId: string;
}

interface PlayerStore {
  playlist: Bhajan[];
  currentIndex: number;
  currentBhajan: Bhajan | null;
  isPlaying: boolean;
  volume: number;
  loop: boolean;
  useYoutube: boolean;

  setPlaylist: (playlist: Bhajan[]) => void;
  play: (bhajan: Bhajan, playlist?: Bhajan[]) => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  next: () => void;
  prev: () => void;
  setVolume: (v: number) => void;
  toggleLoop: () => void;
  setUseYoutube: (v: boolean) => void;
}

export const useBhajanPlayer = create<PlayerStore>((set, get) => ({
  playlist: [],
  currentIndex: 0,
  currentBhajan: null,
  isPlaying: false,
  volume: 0.7,
  loop: true,
  useYoutube: false,

  setPlaylist: (playlist) => set({ playlist }),

  play: (bhajan, playlist) => {
    const list = playlist || get().playlist;
    const idx = list.findIndex(b => b.id === bhajan.id);
    set({ currentBhajan: bhajan, isPlaying: true, playlist: list.length ? list : get().playlist, currentIndex: idx >= 0 ? idx : 0 });
  },

  pause: () => set({ isPlaying: false }),
  resume: () => set({ isPlaying: true }),
  stop: () => set({ currentBhajan: null, isPlaying: false, currentIndex: 0 }),

  next: () => {
    const { playlist, currentIndex, loop } = get();
    if (!playlist.length) return;
    const nextIdx = currentIndex + 1 >= playlist.length ? (loop ? 0 : currentIndex) : currentIndex + 1;
    const next = playlist[nextIdx];
    if (next) set({ currentBhajan: next, currentIndex: nextIdx, isPlaying: true });
  },

  prev: () => {
    const { playlist, currentIndex } = get();
    if (!playlist.length) return;
    const prevIdx = currentIndex - 1 < 0 ? playlist.length - 1 : currentIndex - 1;
    const prev = playlist[prevIdx];
    if (prev) set({ currentBhajan: prev, currentIndex: prevIdx, isPlaying: true });
  },

  setVolume: (v) => set({ volume: Math.max(0, Math.min(1, v)) }),
  toggleLoop: () => set(s => ({ loop: !s.loop })),
  setUseYoutube: (v) => set({ useYoutube: v }),
}));
