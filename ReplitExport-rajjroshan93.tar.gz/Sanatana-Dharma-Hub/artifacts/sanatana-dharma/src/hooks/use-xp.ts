import { useState, useEffect } from 'react';
import { useAuth } from './use-auth';
import { db, isDemoMode } from '../lib/firebase';
import { doc, getDoc, setDoc, updateDoc, increment } from 'firebase/firestore';

export interface UserStats {
  xp: number;
  streak: number;
  lastActive: string;
  quizzesCompleted: number;
  lessonsCompleted: number;
}

const DEFAULT_STATS: UserStats = {
  xp: 0,
  streak: 0,
  lastActive: new Date().toISOString(),
  quizzesCompleted: 0,
  lessonsCompleted: 0
};

export function getLevel(xp: number) {
  if (xp >= 3000) return 'Maharishi';
  if (xp >= 1500) return 'Guru';
  if (xp >= 700) return 'Acharya';
  if (xp >= 300) return 'Yogi';
  if (xp >= 100) return 'Sadhak';
  return 'Shishya';
}

export function useXP() {
  const { user } = useAuth();
  const [stats, setStats] = useState<UserStats>(DEFAULT_STATS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setStats(DEFAULT_STATS);
      setLoading(false);
      return;
    }

    const fetchStats = async () => {
      setLoading(true);
      try {
        if (isDemoMode) {
          const stored = localStorage.getItem(`stats_${user.uid}`);
          if (stored) {
            setStats(JSON.parse(stored));
          } else {
            setStats(DEFAULT_STATS);
            localStorage.setItem(`stats_${user.uid}`, JSON.stringify(DEFAULT_STATS));
          }
        } else {
          const docRef = doc(db, 'users', user.uid);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setStats(docSnap.data() as UserStats);
          } else {
            await setDoc(docRef, DEFAULT_STATS);
            setStats(DEFAULT_STATS);
          }
        }
      } catch (error) {
        console.error("Error fetching stats", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [user]);

  const addXP = async (amount: number, reason: string) => {
    if (!user) return;

    const newStats = { ...stats, xp: stats.xp + amount, lastActive: new Date().toISOString() };
    
    if (reason === 'quiz') newStats.quizzesCompleted += 1;
    if (reason === 'lesson') newStats.lessonsCompleted += 1;

    setStats(newStats);

    if (isDemoMode) {
      localStorage.setItem(`stats_${user.uid}`, JSON.stringify(newStats));
    } else {
      const docRef = doc(db, 'users', user.uid);
      await updateDoc(docRef, {
        xp: increment(amount),
        lastActive: new Date().toISOString(),
        ...(reason === 'quiz' && { quizzesCompleted: increment(1) }),
        ...(reason === 'lesson' && { lessonsCompleted: increment(1) })
      });
    }
  };

  return { stats, loading, addXP, level: getLevel(stats.xp) };
}
