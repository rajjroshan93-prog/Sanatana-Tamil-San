#!/bin/bash

# Sanatana Dharma Deployment Script
# Run this script to build and create a deployment-ready ZIP

set -e

echo "🚀 Starting deployment build..."

# Build the project
echo "📦 Building project..."
npm run build

# Create deployment ZIP
echo "🗜️ Creating deployment ZIP..."
cd dist
zip -r ../sanatana-dharma-deployment.zip .
cd ..

echo "✅ Deployment package created: sanatana-dharma-deployment.zip"
echo ""
echo "📋 ZIP contents:"
unzip -l sanatana-dharma-deployment.zip
echo ""
echo "🎉 Ready for Netlify deployment!"
