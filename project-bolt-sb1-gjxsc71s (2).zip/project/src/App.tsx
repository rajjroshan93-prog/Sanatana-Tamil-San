import { useState, useEffect } from 'react';
import { Heart, Github, GithubIcon, Play, Pause, RotateCcw, Volume2, VolumeX, Star, Sun, Moon, Cloud, Sparkles } from 'lucide-react';

function App() {
  const [count, setCount] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [mantra, setMantra] = useState(' Om Namo Narayanaaya');
  const [muted, setMuted] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [darkMode]);

  const mantras = [
    ' Om Namo Narayanaaya',
    'Om Gam Ganapataye Namaha',
    'Om Namah Shivaya',
    'Om Tryambakam Yajamahe',
    'Om Shanti Shanti Shanti',
    'Aum Sri Ganeshaya Namah',
    'Om Sarve Bhavantu Sukhinah',
    'Aum Mani Padme Hum',
  ];

  const handleMantraChange = () => {
    const randomIndex = Math.floor(Math.random() * mantras.length);
    setMantra(mantras[randomIndex]);
    setCount(0);
  };

  const handleIncrement = () => {
    setCount(prev => prev + 1);
  };

  const handleReset = () => {
    setCount(0);
  };

  return (
    <div className={`min-h-screen transition-all duration-500 ${darkMode
      ? 'bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900'
      : 'bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50'}`}
    >
      {/* Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className={`absolute rounded-full opacity-20 animate-pulse ${darkMode ? 'bg-orange-400' : 'bg-orange-300'}`}
            style={{
              width: Math.random() * 100 + 50,
              height: Math.random() * 100 + 50,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${Math.random() * 3 + 2}s`
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className={`relative z-10 px-4 py-6 ${darkMode ? 'bg-slate-900/80' : 'bg-white/80'} backdrop-blur-md shadow-lg border-b ${darkMode ? 'border-orange-500/30' : 'border-orange-200'}`}>
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${darkMode ? 'bg-gradient-to-br from-orange-400 to-red-600' : 'bg-gradient-to-br from-orange-500 to-red-500'} shadow-lg`}>
              <span className="text-white text-2xl font-bold">ॐ</span>
            </div>
            <div>
              <h1 className={`text-2xl font-bold ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
                Sanatana Dharma
              </h1>
              <p className={`text-sm ${darkMode ? 'text-orange-400/80' : 'text-gray-600'}`}>
                Spiritual Practice Companion
              </p>
            </div>
          </div>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-3 rounded-full transition-all duration-300 ${darkMode
              ? 'bg-slate-800 hover:bg-slate-700 text-orange-300'
              : 'bg-orange-100 hover:bg-orange-200 text-gray-700'}`}
          >
            {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-full text-sm font-medium shadow-lg">
            <Sparkles className="w-4 h-4" />
            Tamil Sanatana Tradition
            <Sparkles className="w-4 h-4" />
          </div>
          <h2 className={`text-4xl md:text-5xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
            <span className="bg-gradient-to-r from-orange-500 to-red-600 bg-clip-text text-transparent">
              Om Namo Narayanaaya
            </span>
          </h2>
          <p className={`text-lg md:text-xl max-w-2xl mx-auto ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
            Connect with divine energy through sacred mantra chanting.
            Track your spiritual progress and deepen your practice.
          </p>
        </div>

        {/* Mantra Card */}
        <div className={`rounded-3xl p-8 mb-8 ${darkMode
          ? 'bg-slate-800/50 backdrop-blur-xl border border-orange-500/30'
          : 'bg-white shadow-2xl border border-orange-100'}`}
        >
          <div className="text-center mb-8">
            <div className={`inline-block mb-4 px-6 py-3 rounded-2xl ${darkMode
              ? 'bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/40'
              : 'bg-gradient-to-r from-orange-100 to-red-100'}`}
            >
              <p className={`text-3xl md:text-4xl font-bold ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
                {mantra}
              </p>
            </div>

            {/* Mala Image */}
            <div className="mb-6 flex justify-center">
              <div className={`w-32 h-32 rounded-full flex items-center justify-center relative ${darkMode
                ? 'bg-gradient-to-br from-orange-400 to-red-600 shadow-2xl'
                : 'bg-gradient-to-br from-orange-300 to-red-400 shadow-xl'}`}
              >
                <div className={`absolute inset-3 rounded-full ${darkMode ? 'bg-slate-900' : 'bg-white'}`}></div>
                <div className="relative z-10 flex flex-col items-center">
                  <Star className={`w-6 h-6 ${darkMode ? 'text-orange-400' : 'text-orange-500'} mb-1`} />
                  <span className={`text-4xl font-bold ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
                    {count}
                  </span>
                </div>
              </div>
            </div>

            <p className={`text-lg mb-6 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Times Chanted
            </p>
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={handleIncrement}
              className={`px-8 py-4 rounded-2xl text-lg font-semibold transition-all duration-300 transform hover:scale-105 ${darkMode
                ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white shadow-lg shadow-orange-500/30 hover:shadow-orange-500/50'
                : 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg hover:shadow-xl'}`}
            >
              <Heart className="w-5 h-5 inline mr-2" />
              Chant
            </button>

            <button
              onClick={handleReset}
              className={`px-6 py-4 rounded-2xl text-lg font-semibold transition-all duration-300 transform hover:scale-105 ${darkMode
                ? 'bg-slate-700 text-orange-300 hover:bg-slate-600'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            >
              <RotateCcw className="w-5 h-5 inline mr-2" />
              Reset
            </button>

            <button
              onClick={handleMantraChange}
              className={`px-6 py-4 rounded-2xl text-lg font-semibold transition-all duration-300 transform hover:scale-105 ${darkMode
                ? 'bg-slate-700 text-orange-300 hover:bg-slate-600'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            >
              <Sparkles className="w-5 h-5 inline mr-2" />
              Change Mantra
            </button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className={`rounded-2xl p-6 text-center transition-all duration-300 ${darkMode
            ? 'bg-slate-800/50 hover:bg-slate-800/70 border border-orange-500/20'
            : 'bg-white hover:shadow-xl border border-orange-100'}`}
          >
            <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${darkMode
              ? 'bg-gradient-to-br from-orange-500 to-red-600'
              : 'bg-gradient-to-br from-orange-400 to-red-500'}`}
            >
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h3 className={`text-xl font-bold mb-2 ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
              Track Progress
            </h3>
            <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Count your mantra repetitions and build a consistent spiritual practice
            </p>
          </div>

          <div className={`rounded-2xl p-6 text-center transition-all duration-300 ${darkMode
            ? 'bg-slate-800/50 hover:bg-slate-800/70 border border-orange-500/20'
            : 'bg-white hover:shadow-xl border border-orange-100'}`}
          >
            <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${darkMode
              ? 'bg-gradient-to-br from-orange-500 to-red-600'
              : 'bg-gradient-to-br from-orange-400 to-red-500'}`}
            >
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className={`text-xl font-bold mb-2 ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
              Sacred Mantras
            </h3>
            <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Choose from powerful Tamil Sanatana mantras for your practice
            </p>
          </div>

          <div className={`rounded-2xl p-6 text-center transition-all duration-300 ${darkMode
            ? 'bg-slate-800/50 hover:bg-slate-800/70 border border-orange-500/20'
            : 'bg-white hover:shadow-xl border border-orange-100'}`}
          >
            <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center ${darkMode
              ? 'bg-gradient-to-br from-orange-500 to-red-600'
              : 'bg-gradient-to-br from-orange-400 to-red-500'}`}
            >
              <Sun className="w-8 h-8 text-white" />
            </div>
            <h3 className={`text-xl font-bold mb-2 ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
              Divine Connection
            </h3>
            <p className={`${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Deepen your spiritual journey with sacred Vedic traditions
            </p>
          </div>
        </div>

        {/* About Section */}
        <div className={`rounded-3xl p-8 ${darkMode
          ? 'bg-slate-800/50 backdrop-blur-xl border border-orange-500/30'
          : 'bg-white shadow-2xl border border-orange-100'}`}
        >
          <h2 className={`text-3xl font-bold mb-6 text-center ${darkMode ? 'text-orange-300' : 'text-gray-800'}`}>
            About Sanatana Dharma
          </h2>
          <div className={`${darkMode ? 'text-gray-300' : 'text-gray-600'} space-y-4 text-lg leading-relaxed`}>
            <p>
              Sanatana Dharma, the eternal way of life, represents the ancient spiritual traditions
              of Tamil culture and the broader Indian subcontinent. Rooted in the timeless wisdom
              of the Vedas, it offers a path to self-realization and divine connection.
            </p>
            <p>
              The practice of mantra chanting has been a cornerstone of spiritual development for
              millennia. Each sacred mantra carries profound vibrations that help purify the mind,
              open the heart, and connect practitioners with the divine energy of the universe.
            </p>
            <p>
              <strong className={darkMode ? 'text-orange-300' : 'text-gray-800'}>
                "Om Namo Narayanaaya"
              </strong>{' '}
              is a powerful mantra dedicated to Lord Vishnu, the preserver of the universe.
              Regular chanting of this mantra brings peace, prosperity, and spiritual enlightenment.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className={`relative z-10 px-4 py-8 mt-12 ${darkMode
        ? 'bg-slate-900/80 border-t border-orange-500/30'
        : 'bg-white/80 border-t border-orange-200'} backdrop-blur-md`}
      >
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            < span className={`text-4xl ${darkMode ? 'text-orange-400' : 'text-orange-500'}`}>
              ॐ
            </span>
          </div>
          <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'} mb-2`}>
            Sanatana Dharma - The Eternal Way
          </p>
          <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-500'}`}>
            Embrace the wisdom of ancient traditions in the modern world
          </p>
          <div className="flex justify-center items-center gap-4 mt-6">
            <a
              href="https://github.com/rajjroshan93-prog/Sanatana-Tamil-San"
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all duration-300 ${darkMode
                ? 'bg-slate-800 hover:bg-slate-700 text-orange-300'
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
            >
              <Github className="w-5 h-5" />
              View on GitHub
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;