# Sanatana Dharma - Tamil Spiritual Practice

A beautiful web application for spiritual practice and mantra chanting following the Tamil Sanatana tradition.

## Features

- Mantra chanting counter with japa mala tracking
- Multiple sacred Tamil mantras
- Dark/Light mode toggle
- Responsive design for all devices
- Beautiful gradients and animations
- Clean and modern UI

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS
- Lucide React (icons)

## Deployment

This project is configured for Netlify deployment with:
- Automatic builds from the `main` branch
- SPA routing support
- Optimized caching headers

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Deployment to Netlify

### Option 1: Drag and Drop
1. Run `npm run build`
2. Drag the `dist` folder to [Netlify Drop](https://app.netlify.com/drop)

### Option 2: GitHub Integration
1. Push this repository to GitHub
2. Connect to Netlify
3. Deploy automatically on push

## Project Structure

```
├── src/
│   ├── App.tsx         # Main application component
│   ├── main.tsx        # Entry point
│   └── index.css      # Global styles
├── index.html         # HTML template
├── netlify.toml       # Netlify configuration
├── package.json       # Dependencies
├── postcss.config.js  # PostCSS config
├── tailwind.config.js # Tailwind config
├── tsconfig.json      # TypeScript config
└── vite.config.ts     # Vite config
```

## License

MIT

## Author

Created by [rajjroshan93-prog](https://github.com/rajjroshan93-prog)

---

🕉️ Om Namo Narayanaaya 🕉️