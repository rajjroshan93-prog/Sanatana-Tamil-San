import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useBhajanPlayer } from '../hooks/use-bhajan-player';
import { Play, Pause, X, SkipForward, SkipBack, Repeat, Music2 } from 'lucide-react';

// YouTube-first audio player.
// Uses the YouTube IFrame postMessage API for reliable play/pause.
// When a new bhajan is selected the iframe key changes → new src with autoplay=1.

export function BhajanPlayer() {
  const {
    currentBhajan, isPlaying, loop,
    pause, resume, stop, next, prev, toggleLoop
  } = useBhajanPlayer();

  const ytRef = useRef<HTMLIFrameElement>(null);
  const [ytLoaded, setYtLoaded] = useState(false);
  const [imgErr, setImgErr] = useState(false);

  // Send postMessage command to the YouTube iframe
  const ytCmd = useCallback((func: string) => {
    ytRef.current?.contentWindow?.postMessage(
      JSON.stringify({ event: 'command', func, args: [] }),
      'https://www.youtube-nocookie.com'
    );
  }, []);

  // Reset loaded state when bhajan changes
  useEffect(() => { setYtLoaded(false); setImgErr(false); }, [currentBhajan?.id]);

  // Sync our play/pause state to YouTube via postMessage
  useEffect(() => {
    if (!ytLoaded) return;
    ytCmd(isPlaying ? 'playVideo' : 'pauseVideo');
  }, [isPlaying, ytLoaded, ytCmd]);

  if (!currentBhajan) return null;

  return (
    <div className="fixed bottom-16 md:bottom-0 left-0 right-0 z-50">
      <div style={{
        background: 'rgba(6,5,14,0.98)',
        borderTop: '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(24px)'
      }}>

        {/* ── YouTube iframe — primary audio source ── */}
        {/* Key on currentBhajan.id forces iframe remount on track change → autoplay=1 starts new track */}
        <iframe
          ref={ytRef}
          key={currentBhajan.id}
          src={`https://www.youtube-nocookie.com/embed/${currentBhajan.youtubeId}?enablejsapi=1&autoplay=1&controls=1&rel=0&modestbranding=1&playsinline=1&color=white`}
          allow="autoplay; encrypted-media; picture-in-picture"
          allowFullScreen
          style={{ width: '100%', height: 72, border: 'none', display: 'block' }}
          title={currentBhajan.title}
          onLoad={() => {
            setYtLoaded(true);
            // Brief delay ensures iframe API is ready
            setTimeout(() => { if (isPlaying) ytCmd('playVideo'); }, 800);
          }}
        />

        {/* ── Custom navigation bar ── */}
        <div className="flex items-center gap-3 px-4 py-2.5">

          {/* Album art */}
          {!imgErr ? (
            <img
              src={currentBhajan.image}
              alt={currentBhajan.title}
              className="w-9 h-9 rounded-lg object-cover flex-shrink-0 border border-white/10"
              onError={() => setImgErr(true)}
            />
          ) : (
            <div className="w-9 h-9 rounded-lg flex-shrink-0 flex items-center justify-center"
              style={{ background: 'rgba(255,107,53,0.15)', border: '1px solid rgba(255,107,53,0.2)' }}>
              <Music2 size={16} className="text-orange-400" />
            </div>
          )}

          {/* Title */}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate leading-tight">{currentBhajan.title}</p>
            <p className="text-xs text-white/40 truncate">{currentBhajan.deity} · {currentBhajan.artist}</p>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={() => { prev(); }}
              className="p-1.5 text-white/40 hover:text-white transition-colors rounded-lg"
              aria-label="Previous"
            >
              <SkipBack size={15} />
            </button>

            <button
              onClick={() => { isPlaying ? pause() : resume(); }}
              className="w-8 h-8 rounded-full flex items-center justify-center text-white flex-shrink-0 transition-all active:scale-95"
              style={{ background: 'linear-gradient(135deg,#FF6B35,#e05a28)' }}
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying
                ? <Pause size={13} fill="white" />
                : <Play size={13} fill="white" className="ml-0.5" />}
            </button>

            <button
              onClick={() => { next(); }}
              className="p-1.5 text-white/40 hover:text-white transition-colors rounded-lg"
              aria-label="Next"
            >
              <SkipForward size={15} />
            </button>

            <button
              onClick={toggleLoop}
              className={`p-1.5 rounded-lg transition-colors ${loop ? 'text-orange-400' : 'text-white/20 hover:text-white/50'}`}
              aria-label="Loop"
            >
              <Repeat size={13} />
            </button>

            <button
              onClick={stop}
              className="p-1.5 text-white/20 hover:text-white/70 transition-colors rounded-lg"
              aria-label="Close player"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
