import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import {
  Home, BookOpen, Music, PlaySquare, Award, User as UserIcon,
  Flame, LogOut, Menu, X, Calendar, BookMarked, Hash
} from 'lucide-react';
import { useAuth } from '../../hooks/use-auth';
import { useXP } from '../../hooks/use-xp';

const navItems = [
  { icon: Home,       label: 'Home',     href: '/' },
  { icon: Flame,      label: 'Darshan',  href: '/darshan' },
  { icon: BookOpen,   label: 'Deities',  href: '/deities' },
  { icon: PlaySquare, label: 'Meditate', href: '/meditation' },
  { icon: Music,      label: 'Bhajans',  href: '/bhajans' },
  { icon: Hash,       label: 'Mantra',   href: '/mantra-counter' },
  { icon: Calendar,   label: 'Calendar', href: '/calendar' },
  { icon: BookMarked, label: 'Stories',  href: '/stories' },
  { icon: Award,      label: 'Quiz',     href: '/quiz' },
  { icon: BookOpen,   label: 'Learn',    href: '/learn' },
];

// Bottom nav shows 5 most-used items on mobile
const mobileNav = [
  { icon: Home,       label: 'Home',    href: '/' },
  { icon: BookOpen,   label: 'Deities', href: '/deities' },
  { icon: Music,      label: 'Bhajans', href: '/bhajans' },
  { icon: Hash,       label: 'Mantra',  href: '/mantra-counter' },
  { icon: Calendar,   label: 'Calendar',href: '/calendar' },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, signOut } = useAuth();
  const { stats, level } = useXP();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">

      {/* ── Desktop Sidebar ──────────────────────────────────────────────── */}
      <aside className="hidden md:flex flex-col w-56 border-r sticky top-0 h-screen z-40 flex-shrink-0"
        style={{ background: 'rgba(10,9,20,0.95)', borderColor: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(16px)' }}>
        {/* Brand */}
        <div className="px-5 py-5 border-b" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
          <h1 className="text-lg font-cinzel font-bold"
            style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Sanatana
          </h1>
          <p className="text-[10px] font-cinzel text-white/30 tracking-[0.25em] mt-0.5">DHARMA</p>
        </div>

        {/* Nav items */}
        <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto">
          {navItems.map(item => {
            const active = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition-all duration-200 cursor-pointer text-sm ${
                  active
                    ? 'text-white font-semibold'
                    : 'text-white/40 hover:text-white/80 hover:bg-white/5'
                }`}
                  style={active ? { background: 'rgba(255,107,53,0.12)', boxShadow: '0 0 12px rgba(255,107,53,0.08)' } : {}}>
                  <item.icon size={16} className={active ? 'text-orange-400' : ''} />
                  <span>{item.label}</span>
                  {active && <span className="ml-auto w-1 h-4 rounded-full bg-orange-400" />}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User section */}
        {user ? (
          <div className="p-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
            <Link href="/profile">
              <div className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer mb-2">
                <img
                  src={user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName ?? 'U')}&background=FF6B35&color=fff`}
                  alt="Avatar" className="w-8 h-8 rounded-full border border-orange-500/30 flex-shrink-0" />
                <div className="flex-1 overflow-hidden">
                  <p className="text-xs font-semibold text-white truncate">{user.displayName}</p>
                  <p className="text-[10px] text-orange-400/70 font-cinzel">{level} • {stats?.xp || 0} XP</p>
                </div>
              </div>
            </Link>
            <button onClick={signOut}
              className="w-full flex items-center justify-center gap-1.5 text-xs text-white/30 hover:text-red-400 transition-colors py-1.5 rounded-lg hover:bg-red-500/8">
              <LogOut size={12} /> Sign Out
            </button>
          </div>
        ) : (
          <div className="p-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
            <Link href="/login">
              <div className="w-full py-2.5 rounded-xl text-center text-sm font-semibold text-white transition-all cursor-pointer"
                style={{ background: 'linear-gradient(135deg,rgba(255,107,53,0.2),rgba(123,47,190,0.2))', border: '1px solid rgba(255,107,53,0.2)' }}>
                Sign In
              </div>
            </Link>
          </div>
        )}
      </aside>

      {/* ── Mobile Top Bar ───────────────────────────────────────────────── */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 h-14"
        style={{ background: 'rgba(10,9,20,0.95)', borderBottom: '1px solid rgba(255,255,255,0.07)', backdropFilter: 'blur(16px)' }}>
        <h1 className="text-base font-cinzel font-bold"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Sanatana Dharma
        </h1>
        <button onClick={() => setMobileMenuOpen(v => !v)} className="p-2 text-white/50 hover:text-white transition-colors">
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* ── Mobile Full Menu ─────────────────────────────────────────────── */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 pt-14"
          style={{ background: 'rgba(10,9,20,0.98)', backdropFilter: 'blur(20px)' }}>
          <nav className="p-4 space-y-1">
            {navItems.map(item => {
              const active = location === item.href || (item.href !== '/' && location.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href}>
                  <div onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all cursor-pointer ${active ? 'text-white font-semibold' : 'text-white/50'}`}
                    style={active ? { background: 'rgba(255,107,53,0.12)' } : {}}>
                    <item.icon size={18} className={active ? 'text-orange-400' : ''} />
                    <span className="text-base">{item.label}</span>
                  </div>
                </Link>
              );
            })}
            <div className="pt-4 border-t mt-4" style={{ borderColor: 'rgba(255,255,255,0.07)' }}>
              {user ? (
                <button onClick={() => { signOut(); setMobileMenuOpen(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/40 hover:text-red-400 transition-colors">
                  <LogOut size={18} /> Sign Out
                </button>
              ) : (
                <Link href="/login">
                  <div onClick={() => setMobileMenuOpen(false)}
                    className="px-4 py-3 rounded-xl text-white font-semibold text-center"
                    style={{ background: 'linear-gradient(135deg,#FF6B35,#7B2FBE)' }}>
                    Sign In with Google
                  </div>
                </Link>
              )}
            </div>
          </nav>
        </div>
      )}

      {/* ── Main Content ─────────────────────────────────────────────────── */}
      <main className="flex-1 pb-20 md:pb-0 min-h-screen relative z-10 mt-14 md:mt-0">
        {children}
      </main>

      {/* ── Mobile Bottom Nav ────────────────────────────────────────────── */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 flex justify-around items-center px-2 py-1.5"
        style={{ background: 'rgba(8,7,18,0.97)', borderTop: '1px solid rgba(255,255,255,0.07)', backdropFilter: 'blur(16px)' }}>
        {mobileNav.map(item => {
          const active = location === item.href || (item.href !== '/' && location.startsWith(item.href));
          return (
            <Link key={item.href} href={item.href}>
              <div className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all ${active ? 'text-orange-400' : 'text-white/35 hover:text-white/60'}`}>
                <item.icon size={20} />
                <span className="text-[9px] font-medium leading-none">{item.label}</span>
              </div>
            </Link>
          );
        })}
        <Link href={user ? '/profile' : '/login'}>
          <div className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-all ${location === '/profile' ? 'text-orange-400' : 'text-white/35'}`}>
            <UserIcon size={20} />
            <span className="text-[9px] font-medium leading-none">{user ? 'Profile' : 'Login'}</span>
          </div>
        </Link>
      </nav>
    </div>
  );
}
