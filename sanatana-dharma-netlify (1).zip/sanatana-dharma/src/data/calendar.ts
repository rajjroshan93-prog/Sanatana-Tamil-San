export interface HinduFestival {
  id: string;
  name: string;
  date: string; // ISO date YYYY-MM-DD
  type: 'major' | 'minor' | 'fasting' | 'puja';
  deity?: string;
  description: string;
  color: string;
}

// Hindu festivals for 2025–2026
export const hinduFestivals: HinduFestival[] = [
  // 2025 remaining
  { id: "diwali-2025", name: "Diwali", date: "2025-10-20", type: "major", deity: "Lakshmi", description: "Festival of lights celebrating Rama's return and Lakshmi's blessing of prosperity.", color: "#fbbf24" },
  { id: "chhath-2025", name: "Chhath Puja", date: "2025-10-28", type: "puja", deity: "Surya", description: "Four-day festival devoted to the Sun god Surya and Chhathi Maiya.", color: "#f97316" },
  { id: "kartik-purnima-2025", name: "Kartik Purnima", date: "2025-11-05", type: "major", description: "Sacred full moon of Kartik month — bathing in holy rivers on this day grants moksha.", color: "#e2e8f0" },
  { id: "gita-jayanti-2025", name: "Gita Jayanti", date: "2025-12-01", type: "major", deity: "Krishna", description: "Celebrates the day Krishna delivered the Bhagavad Gita to Arjuna.", color: "#a78bfa" },

  // 2026
  { id: "makar-sankranti", name: "Makar Sankranti", date: "2026-01-14", type: "major", deity: "Surya", description: "Sun's transit into Capricorn — marks the end of winter and the beginning of harvest season. Kite flying and sesame sweets.", color: "#facc15" },
  { id: "pongal", name: "Pongal", date: "2026-01-15", type: "major", deity: "Surya", description: "South Indian harvest festival giving thanks to the Sun god for a bountiful harvest.", color: "#fde68a" },
  { id: "vasant-panchami", name: "Vasant Panchami", date: "2026-02-02", type: "major", deity: "Saraswati", description: "Celebrates the arrival of spring and honours Saraswati, goddess of knowledge and arts.", color: "#fde68a" },
  { id: "maha-shivaratri", name: "Maha Shivaratri", date: "2026-02-26", type: "major", deity: "Shiva", description: "The great night of Shiva — devotees fast, chant Om Namah Shivaya, and worship Shiva through the night.", color: "#818cf8" },
  { id: "holi", name: "Holi", date: "2026-03-23", type: "major", deity: "Krishna", description: "Festival of colours celebrating the triumph of good over evil and the eternal love of Radha-Krishna.", color: "#f472b6" },
  { id: "gudi-padwa", name: "Gudi Padwa / Ugadi", date: "2026-03-30", type: "major", description: "Hindu New Year celebrated in Maharashtra and South India — marks the beginning of a new Samvat.", color: "#34d399" },
  { id: "ram-navami", name: "Ram Navami", date: "2026-04-08", type: "major", deity: "Rama", description: "Birthday of Lord Rama, the seventh avatar of Vishnu. Celebrated with readings of the Ramayana.", color: "#34d399" },
  { id: "hanuman-jayanti", name: "Hanuman Jayanti", date: "2026-04-14", type: "major", deity: "Hanuman", description: "Birthday of Lord Hanuman. Devotees recite the Hanuman Chalisa and visit Hanuman temples.", color: "#fb923c" },
  { id: "akshaya-tritiya", name: "Akshaya Tritiya", date: "2026-04-28", type: "major", deity: "Vishnu", description: "An auspicious day for new beginnings, buying gold, and starting important ventures. Believed to bring unending prosperity.", color: "#fbbf24" },
  { id: "buddha-purnima", name: "Buddha Purnima", date: "2026-05-12", type: "major", description: "Celebrates the birth, enlightenment, and passing of Gautama Buddha.", color: "#a78bfa" },
  { id: "vat-savitri", name: "Vat Savitri Puja", date: "2026-06-09", type: "fasting", description: "Women fast and pray for the long life of their husbands, re-enacting the story of Savitri and Satyavan.", color: "#f472b6" },
  { id: "guru-purnima", name: "Guru Purnima", date: "2026-07-11", type: "major", description: "Day to honour and express gratitude to spiritual teachers. Dedicated to Sage Vyasa who compiled the Vedas.", color: "#fbbf24" },
  { id: "ashadhi-ekadashi", name: "Ashadhi Ekadashi", date: "2026-07-16", type: "fasting", deity: "Vishnu", description: "Beginning of Chaturmas (four holy months). Devotees fast and observe Vaishnava vows.", color: "#38bdf8" },
  { id: "nag-panchami", name: "Nag Panchami", date: "2026-07-27", type: "puja", description: "Worship of serpents (Nagas) — milk is offered at snake holes and temples.", color: "#4ade80" },
  { id: "raksha-bandhan", name: "Raksha Bandhan", date: "2026-08-14", type: "major", description: "Festival celebrating the bond of siblings. Sisters tie a rakhi on their brother's wrist for his protection.", color: "#f472b6" },
  { id: "janmashtami", name: "Janmashtami", date: "2026-08-22", type: "major", deity: "Krishna", description: "Birth anniversary of Lord Krishna. Celebrated with midnight worship, fasting, bhajans, and Dahi Handi.", color: "#a78bfa" },
  { id: "ganesh-chaturthi", name: "Ganesh Chaturthi", date: "2026-09-10", type: "major", deity: "Ganesha", description: "10-day festival celebrating Ganesha's birthday. Elaborate clay idols are installed and then immersed in water.", color: "#fbbf24" },
  { id: "navratri", name: "Navratri", date: "2026-10-02", type: "major", deity: "Durga", description: "Nine nights of worship of the Divine Mother in her nine forms. Garba dances are performed through the nights.", color: "#f87171" },
  { id: "dussehra", name: "Dussehra / Vijayadasami", date: "2026-10-11", type: "major", deity: "Durga", description: "Celebrates Durga's victory over Mahishasura and Rama's victory over Ravana — triumph of good over evil.", color: "#ef4444" },
  { id: "dhanteras", name: "Dhanteras", date: "2026-11-07", type: "major", deity: "Kubera", description: "The first day of Diwali — auspicious for buying gold, silver, and new utensils. Dedicated to Kubera.", color: "#fbbf24" },
  { id: "diwali-2026", name: "Diwali", date: "2026-11-08", type: "major", deity: "Lakshmi", description: "Festival of lights celebrating Rama's return to Ayodhya. Lakshmi Puja is performed at night.", color: "#fbbf24" },
  { id: "bhai-dooj", name: "Bhai Dooj", date: "2026-11-10", type: "major", deity: "Yama", description: "Sisters pray for brothers' long lives — a festival of sibling love also associated with Yama and Yamuna.", color: "#f472b6" },
  { id: "kartik-purnima-2026", name: "Kartik Purnima", date: "2026-11-24", type: "major", description: "The holiest full moon — Dev Diwali in Varanasi with thousands of lamps floated on the Ganges.", color: "#e2e8f0" },
  { id: "vaikunta-ekadashi", name: "Vaikunta Ekadashi", date: "2026-12-29", type: "fasting", deity: "Vishnu", description: "The most important Ekadashi — the gates of Vaikuntha (Vishnu's heaven) are said to open on this day.", color: "#38bdf8" },
];

export const fastingDays = [
  "Ekadasi (11th day of each lunar fortnight)",
  "Pradosh (13th day — for Shiva devotees)",
  "Purnima (Full Moon — for Satyanarayan Puja)",
  "Amavasya (New Moon — for ancestors)",
  "Monday (for Shiva)",
  "Tuesday (for Hanuman & Durga)",
  "Friday (for Lakshmi)",
  "Saturday (for Hanuman & Saturn)"
];

export function getUpcomingFestivals(count = 5): HinduFestival[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return hinduFestivals
    .filter(f => new Date(f.date) >= today)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, count);
}

export function getFestivalsForMonth(year: number, month: number): HinduFestival[] {
  return hinduFestivals.filter(f => {
    const d = new Date(f.date);
    return d.getFullYear() === year && d.getMonth() === month;
  });
}

export function getDaysUntil(dateStr: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}
