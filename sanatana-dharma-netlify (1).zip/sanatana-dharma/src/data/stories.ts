export interface SacredStory {
  id: string;
  title: string;
  subtitle: string;
  deity: string;
  category: 'creation' | 'avatar' | 'devotion' | 'wisdom' | 'battle';
  image: string;
  gradientFrom: string;
  gradientTo: string;
  summary: string;
  story: string;
  moral: string;
  source: string;
}

const WM = 'https://upload.wikimedia.org/wikipedia/commons/thumb';

export const sacredStories: SacredStory[] = [
  {
    id: "samudra-manthan",
    title: "Samudra Manthan",
    subtitle: "The Churning of the Cosmic Ocean",
    deity: "Vishnu",
    category: "creation",
    image: `${WM}/2/2c/Vishnu_Bromha_Shiva.jpg/400px-Vishnu_Bromha_Shiva.jpg`,
    gradientFrom: "#1e3a5f",
    gradientTo: "#0f172a",
    summary: "Gods and demons churned the cosmic ocean to obtain Amrita — the nectar of immortality.",
    story: `Long ago, the gods (Devas) had lost their strength after being cursed. Lord Vishnu advised them to join forces with the demons (Asuras) to churn the primordial Ocean of Milk and obtain Amrita — the nectar of immortality.

Mount Mandara was used as the churning rod, and the great serpent Vasuki as the rope. Vishnu himself took the form of a giant tortoise (Kurma avatar) to support the mountain on his back as it spun.

As they churned, many divine treasures emerged:
• Kamadhenu — the divine cow
• Kalpavriksha — the wish-granting tree  
• Lakshmi — who chose Vishnu as her consort
• Chandra — the Moon god
• Dhanvantari — the divine physician with a pot of Amrita
• Halahala — a terrible poison that threatened to destroy all creation

Lord Shiva, to save the world, drank the deadly poison and held it in his throat, turning it blue — hence he is called Neelakantha (the blue-throated one).

Finally, when the Asuras tried to seize the Amrita, Vishnu took the beautiful form of Mohini to distract them and secretly distributed the nectar to the gods, restoring their divine power.`,
    moral: "Cooperation, even with adversaries, can bring great blessings. And sacrifice — like Shiva drinking the poison — is the mark of true greatness.",
    source: "Vishnu Purana, Bhagavata Purana"
  },
  {
    id: "ganesha-birth",
    title: "The Birth of Ganesha",
    subtitle: "How the Elephant God Came to Be",
    deity: "Ganesha",
    category: "creation",
    image: `${WM}/a/a6/Ganesh_Basohli_miniature_circa_1730_Dubost_p73.jpg/400px-Ganesh_Basohli_miniature_circa_1730_Dubost_p73.jpg`,
    gradientFrom: "#451a03",
    gradientTo: "#1c0a00",
    summary: "Parvati created a son from sandalwood paste, and Shiva gave him the head of an elephant.",
    story: `Once, while Shiva was away in deep meditation, Goddess Parvati wished for a son to guard her chambers. She fashioned a boy from the sandalwood paste she used for her bath, breathed life into him, and named him Ganesha.

She instructed Ganesha to guard the door and let no one enter while she bathed. When Shiva returned, Ganesha — not knowing him — blocked his path. Shiva's ganas (attendants) tried to remove the boy but failed. Angered, Shiva himself fought the boy and, in the battle, severed his head.

When Parvati emerged and saw what had happened, she was filled with grief and rage. The entire universe trembled at her sorrow. To console her, Shiva sent his attendants to bring the head of the first creature they found sleeping with its head pointing north.

They found an elephant, brought its head, and Shiva placed it upon Ganesha's shoulders, restoring him to life. Shiva declared that Ganesha would be the foremost among gods — worshipped first before any deity, the remover of all obstacles, the lord of new beginnings.`,
    moral: "Out of tragedy can come transformation. What seems like a loss can become a divine gift. Ganesha's unique form reminds us to see wisdom in what is different.",
    source: "Shiva Purana"
  },
  {
    id: "ramayana",
    title: "The Ramayana",
    subtitle: "Rama's Journey — the Epic of Dharma",
    deity: "Rama",
    category: "avatar",
    image: "https://images.unsplash.com/photo-1534685785745-60a2cea0ec34?w=400",
    gradientFrom: "#14532d",
    gradientTo: "#052e16",
    summary: "Prince Rama's 14-year exile, his wife Sita's abduction, and his triumphant return to Ayodhya.",
    story: `Prince Rama of Ayodhya was the ideal son, husband, and king — the seventh avatar of Vishnu born to restore dharma. When his stepmother's wishes led to his exile from the kingdom for 14 years, Rama accepted this fate without complaint.

His devoted wife Sita and loyal brother Lakshmana accompanied him into the forest. There, the demon king Ravana of Lanka — the most learned but most arrogant of beings — abducted Sita by disguise while Rama and Lakshmana were drawn away.

Rama searched everywhere for Sita. His ally Hanuman — the son of the wind god, endowed with extraordinary strength and devotion — leapt across the ocean to Lanka, found Sita, and reported back.

Rama built a bridge across the ocean with the help of an army of monkeys and bears. For nine days he battled Ravana's forces. On the tenth day (Dussehra), Rama slew Ravana with the Brahmastra arrow.

Sita was freed and proved her purity through the Agni Pariksha (fire test). The reunited family returned to Ayodhya, where the people lit lamps to welcome them — this is why we celebrate Diwali.

Rama ruled as the ideal king, Ram Rajya — a kingdom of perfect justice and prosperity.`,
    moral: "Dharma must be upheld even at great personal cost. Love, loyalty, and righteousness always triumph over arrogance and power.",
    source: "Valmiki Ramayana, Tulsidas's Ramcharitmanas"
  },
  {
    id: "krishna-birth",
    title: "The Birth of Krishna",
    subtitle: "The Divine Child of Mathura",
    deity: "Krishna",
    category: "avatar",
    image: `${WM}/7/7e/Young_Krishna.jpg/400px-Young_Krishna.jpg`,
    gradientFrom: "#1e1b4b",
    gradientTo: "#0f0a2c",
    summary: "Krishna was born at midnight to free the world from the tyrant Kamsa.",
    story: `When the tyrant King Kamsa of Mathura heard a divine prophecy that his sister Devaki's eighth son would kill him, he imprisoned Devaki and her husband Vasudeva and killed each child born to them.

When the eighth child — Lord Krishna — was born at midnight on the Ashtami of Shravana month, a miracle happened. The guards fell asleep, the prison chains fell away, and the prison doors swung open on their own.

Vasudeva carried the newborn Krishna through the monsoon night across the flooded Yamuna River. The river parted to let them through, and the divine serpent Shesha spread his hood to protect the baby from the rain.

Vasudeva placed Krishna with Nanda and Yashoda in Vrindavan, bringing their newborn daughter back to the prison. When Kamsa tried to kill this baby, she transformed into the goddess Yogamaya and told him: "Your slayer is already born and safe."

Krishna grew up in Vrindavan among the cowherds, enchanting everyone with his flute, his playful mischief, and his divine love. He defeated many demons sent by Kamsa, eventually returning to Mathura to fulfill the prophecy.`,
    moral: "No force can stop the Divine from entering the world when the time is right. Love — like Yashoda's for Krishna — is itself divine.",
    source: "Bhagavata Purana (10th Skandha)"
  },
  {
    id: "durga-mahishasura",
    title: "Durga Slays Mahishasura",
    subtitle: "The Nine-Day Battle",
    deity: "Durga",
    category: "battle",
    image: `${WM}/e/e6/Durga10h.jpg/400px-Durga10h.jpg`,
    gradientFrom: "#7f1d1d",
    gradientTo: "#3b0a0a",
    summary: "The combined power of all gods created Durga to defeat the invincible demon Mahishasura.",
    story: `The demon Mahishasura performed fierce austerities and received a boon from Brahma: no male — human, demon, or god — could kill him. Armed with this invincibility, he defeated the gods and conquered the three worlds.

The gods, led by Brahma, went to Vishnu and Shiva. In their collective anger, divine light poured from each god's body, coalescing into a brilliant goddess — Durga, the invincible. Each god gave her a weapon: Vishnu's discus, Shiva's trident, Indra's thunderbolt, Agni's flames, Yama's staff, Vayu's bow.

For nine days and nights, Durga battled Mahishasura and his army. Each time she slew a demon general, Mahishasura changed form — from buffalo to lion, to human, to elephant. Finally, Durga pinned him with her foot and pierced him with her trident.

The gods rejoiced. The three worlds were freed. And each year at Navratri, we celebrate those nine nights of battle — and on the tenth day (Vijayadasami), we celebrate Durga's glorious victory.`,
    moral: "When the situation seems hopeless, united devotion and divine power can overcome any force. The feminine divine energy (Shakti) is the ultimate power of the universe.",
    source: "Devi Mahatmyam (Markandeya Purana)"
  },
  {
    id: "nachiketa",
    title: "Nachiketa and Yama",
    subtitle: "The Secret of Death",
    deity: "Yama",
    category: "wisdom",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400",
    gradientFrom: "#14532d",
    gradientTo: "#0f172a",
    summary: "A brave boy traveled to the realm of Death and asked Yama the secret of what happens after death.",
    story: `Long ago, a young brahmin boy named Nachiketa watched his father perform a yajna (sacred ceremony) and give away old, weak cows as charity — cows that had given their last milk. Nachiketa was troubled: such charity without true spirit was hollow.

He asked his father, "To whom have you given me?" Three times he asked, until his father, annoyed, said: "To Yama (Death) I give you!"

Nachiketa, accepting this as his father's word, traveled to the realm of Yama. But Yama was away for three days. When Yama returned and found a brahmin boy waiting unfed for three days, he offered three boons to make amends.

For his first boon, Nachiketa asked to return home safely to his father. For his second, he asked for the knowledge of the sacred fire that leads to heaven.

For his third boon, Nachiketa asked: "What happens to a man after death? Some say he exists, some say he does not. Teach me this secret."

Yama tried to dissuade him — offering wealth, kingdoms, beautiful experiences, anything. Nachiketa refused them all. Such is the boy who is worthy of the highest knowledge.

Finally, Yama taught Nachiketa the deepest wisdom: the Atman (Self) is eternal, unborn, never dies. It is smaller than the smallest and greater than the greatest. The one who knows this Self is freed from death.`,
    moral: "True wisdom about the soul cannot be bought with worldly things. Only the one who has turned away from all pleasure and fixed their heart on truth is worthy of the highest knowledge.",
    source: "Katha Upanishad"
  },
  {
    id: "descent-of-ganga",
    title: "The Descent of the Ganga",
    subtitle: "How the Sacred River Came to Earth",
    deity: "Shiva",
    category: "devotion",
    image: `${WM}/d/d9/Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg/400px-Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg`,
    gradientFrom: "#1e3a5f",
    gradientTo: "#0f172a",
    summary: "King Bhagiratha's thousand-year penance brought the celestial river Ganga down to Earth.",
    story: `Long ago, King Sagara's 60,000 sons were burned to ashes by the sage Kapila's angry gaze when they disturbed his meditation. Only the water of the celestial river Ganga, which flowed in heaven, could liberate their souls.

Sagara's descendants performed penances for generations to bring Ganga to Earth. Finally, King Bhagiratha undertook a thousand-year tapas (austerity), standing on one leg with arms raised, living only on air.

Brahma appeared and granted his wish — but warned that the force of Ganga falling from heaven would shatter the Earth. Only Shiva could bear her descent.

Bhagiratha then performed more tapas to propitiate Shiva. The great god agreed. When Ganga descended, proud of her power, thinking she would drown even Shiva — Shiva caught her in his matted locks (jata) and held her. She wandered, lost, in his hair for years.

Bhagiratha prayed again. Shiva released a small stream of Ganga from his locks. This stream flowed down to Earth, following Bhagiratha's chariot, purifying everything it touched, and eventually reached the ashes of Sagara's sons — liberating their souls.

This is why the Ganges River is the most sacred in Hinduism, and why Shiva is called Gangadhara — the bearer of the Ganga.`,
    moral: "Persistent, selfless devotion — not for oneself but for one's ancestors and all of humanity — can move even the highest powers. Where devotion is pure, miracles flow.",
    source: "Valmiki Ramayana, Bhagavata Purana"
  },
  {
    id: "prahlada",
    title: "Prahlada and Narasimha",
    subtitle: "The Devotee Who Could Not Be Destroyed",
    deity: "Vishnu",
    category: "devotion",
    image: "https://images.unsplash.com/photo-1577083552431-6e5fd01988a5?w=400",
    gradientFrom: "#1e3a5f",
    gradientTo: "#0c1a3b",
    summary: "The demon king's own son became Vishnu's greatest devotee, and Vishnu took a fierce form to protect him.",
    story: `Hiranyakashipu was a powerful demon king who hated Vishnu. He performed severe tapas and received a boon from Brahma: he could not be killed by man or animal, by day or night, indoors or outdoors, on earth or in the sky, by any weapon.

Believing himself immortal, Hiranyakashipu declared himself God and demanded all worship him. But his own son, Prahlada, refused — for Prahlada was a devoted worshipper of Vishnu from his mother's womb.

Hiranyakashipu tried everything to destroy Prahlada's faith: throwing him off a cliff, into fire, into the ocean, sending venomous snakes, having elephants trample him, giving him poison. Nothing worked — Vishnu's grace protected the boy.

Finally, in rage, the king pointed to a pillar: "Is your Vishnu in this pillar?" "Yes," said Prahlada, "Vishnu is everywhere." The king struck the pillar.

Vishnu burst forth as Narasimha — half-man, half-lion (neither fully man nor animal). At dusk (neither day nor night), at the threshold (neither inside nor outside), he placed Hiranyakashipu on his thighs (neither earth nor sky) and tore him apart with his lion claws (no weapon).

The boon was kept — and yet evil was destroyed. Vishnu placed young Prahlada on the throne.`,
    moral: "True devotion cannot be destroyed by any power in the universe. And God always finds a way to protect his devotees and uphold dharma.",
    source: "Bhagavata Purana (7th Skandha)"
  }
];
