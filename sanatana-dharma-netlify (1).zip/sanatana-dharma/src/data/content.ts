// Wikipedia Special:FilePath redirects to actual Wikimedia CDN — most stable URL format.
// onError fallback gradients are designed to look beautiful on their own.
const WP = 'https://en.wikipedia.org/wiki/Special:FilePath';

export const deities = [
  {
    id: "shiva",
    name: "Shiva",
    title: "The Destroyer & Transformer",
    image: `${WP}/Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg?width=500`,
    fallbackGradient: "from-indigo-700 via-purple-800 to-indigo-900",
    glowColor: "rgba(129,140,248,0.5)",
    accentColor: "#a5b4fc",
    description: "Lord Shiva is the Supreme Being within Shaivism, part of the Trimurti alongside Brahma and Vishnu. He represents the cycle of creation, preservation, and dissolution.",
    mythology: "Shiva dances the cosmic Tandava, symbolising the cycle of creation and destruction. He meditates at Mount Kailash, and the sacred river Ganga flows from his matted locks. His third eye holds the power to destroy everything.",
    attributes: ["Trident (Trishul)", "Damaru (Drum)", "Crescent Moon", "Third Eye", "Snake (Vasuki)", "Rudraksha Beads"],
    mantra: "Om Namah Shivaya",
    mantraFull: "ॐ नमः शिवाय\nOm Namah Shivaya\n\nI bow to Lord Shiva.\nThe five-syllable mantra that honours all five elements.",
    festivals: ["Mahashivratri", "Shravan Month", "Pradosh Vrat"]
  },
  {
    id: "vishnu",
    name: "Vishnu",
    title: "The Preserver",
    image: `${WP}/Narayana-Vishnu-Mural.jpg?width=500`,
    fallbackGradient: "from-blue-700 via-sky-800 to-blue-900",
    glowColor: "rgba(56,189,248,0.45)",
    accentColor: "#7dd3fc",
    description: "Vishnu is the preserver and protector of the universe who descends to Earth in various avatars to restore cosmic order whenever evil threatens to overwhelm the world.",
    mythology: "Vishnu rests on the cosmic serpent Ananta-Shesha in the primordial ocean of milk. He has incarnated ten times (Dashavatara) to protect dharma in every age.",
    attributes: ["Conch (Panchajanya)", "Discus (Sudarshana Chakra)", "Mace (Kaumodaki)", "Lotus", "Kaustubha Gem"],
    mantra: "Om Namo Narayanaya",
    mantraFull: "ॐ नमो नारायणाय\nOm Namo Narayanaya\n\nI bow to Narayana (Vishnu).\nThe eight-syllable mantra that ensures liberation and divine grace.",
    festivals: ["Vaikuntha Ekadasi", "Vishnu Puja", "Diwali"]
  },
  {
    id: "brahma",
    name: "Brahma",
    title: "The Creator",
    image: `${WP}/Brahma_Pushkar.jpg?width=500`,
    fallbackGradient: "from-amber-600 via-orange-700 to-yellow-800",
    glowColor: "rgba(251,191,36,0.5)",
    accentColor: "#fcd34d",
    description: "Brahma is the creator god in the Trimurti, responsible for the creation of the universe and all living beings. He is the progenitor of all existence and the source of the four Vedas.",
    mythology: "Brahma emerged from a golden egg (Hiranyagarbha) or from the lotus that grew from Vishnu's navel. He creates the universe at the beginning of each cosmic cycle.",
    attributes: ["Four Faces", "Four Vedas", "Lotus Throne", "Prayer Beads (Aksamala)", "Water Pot (Kamandalu)", "Swan (Hamsa)"],
    mantra: "Om Brahma Devaya Namaha",
    mantraFull: "ॐ ब्रह्म देवाय नमः\nOm Brahma Devaya Namaha\n\nI bow to Lord Brahma.\nThe creator of all worlds and the source of all Vedic knowledge.",
    festivals: ["Brahma Jayanti", "Kartik Purnima", "Pushkar Fair"]
  },
  {
    id: "krishna",
    name: "Krishna",
    title: "The God of Compassion & Love",
    image: `${WP}/Lord_Krishna_by_Raja_Ravi_Varma.jpg?width=500`,
    fallbackGradient: "from-violet-700 via-purple-800 to-violet-900",
    glowColor: "rgba(167,139,250,0.5)",
    accentColor: "#c4b5fd",
    description: "Krishna is the eighth avatar of Vishnu and the Supreme God in his own right — the embodiment of divine love, wisdom, and the ultimate teacher who revealed the Bhagavad Gita.",
    mythology: "Born in Mathura, Krishna grew up among the cowherds of Vrindavan, enchanting all with his flute. His divine play (Leela) with the Gopis represents the soul's longing for union with the Divine.",
    attributes: ["Flute (Bansuri)", "Peacock Feather", "Sudarshana Chakra", "Yellow Garments", "Cows", "Lotus"],
    mantra: "Hare Krishna Mahamantra",
    mantraFull: "हरे कृष्ण हरे कृष्ण\nकृष्ण कृष्ण हरे हरे\nहरे राम हरे राम\nराम राम हरे हरे\n\nHare Krishna Hare Krishna\nKrishna Krishna Hare Hare\nHare Rama Hare Rama\nRama Rama Hare Hare",
    festivals: ["Janmashtami", "Holi", "Govardhan Puja"]
  },
  {
    id: "rama",
    name: "Rama",
    title: "The Ideal King & Avatar",
    image: `${WP}/Ramavishnuavatar.jpg?width=500`,
    fallbackGradient: "from-emerald-600 via-green-700 to-emerald-900",
    glowColor: "rgba(52,211,153,0.45)",
    accentColor: "#6ee7b7",
    description: "Rama is the seventh avatar of Vishnu, the ideal man and perfect king. His life story, the Ramayana, is the foundational epic of Hindu civilization celebrating righteousness and duty.",
    mythology: "Rama was born in Ayodhya to restore dharma on Earth. Exiled for 14 years, he crossed the ocean to Lanka to rescue his wife Sita from the demon king Ravana, aided by the army of Hanuman.",
    attributes: ["Bow and Arrow", "Crown", "Blue Skin", "Sita (consort)", "Hanuman (devotee)", "Lotus Eyes"],
    mantra: "Jai Shri Ram",
    mantraFull: "जय श्री राम\nJai Shri Ram\n\nSri Rama Rama Rameti\nRame Rame Manorame\nSahasranama Tattulyam\nRama Nama Varanane",
    festivals: ["Ram Navami", "Diwali", "Vivah Panchami"]
  },
  {
    id: "hanuman",
    name: "Hanuman",
    title: "The Devoted Warrior",
    image: `${WP}/Hanuman.jpg?width=500`,
    fallbackGradient: "from-orange-600 via-red-700 to-orange-900",
    glowColor: "rgba(249,115,22,0.55)",
    accentColor: "#fdba74",
    description: "Hanuman is the divine monkey god, the greatest devotee of Rama, embodying strength, devotion, courage, and selfless service. He is worshipped for protection and removing obstacles.",
    mythology: "Son of the wind god Vayu, Hanuman helped Rama rescue Sita from Lanka. He leaped across the ocean, set Lanka ablaze with his burning tail, and brought the Sanjeevani herb to save Lakshmana.",
    attributes: ["Mace (Gada)", "Mountain", "Saffron Robe", "Tail", "Monkey Form", "Rama's name on heart"],
    mantra: "Hanuman Chalisa",
    mantraFull: "श्री गुरु चरण सरोज रज\nनिज मन मुकुरु सुधारि\nबरनऊँ रघुबर बिमल जसु\nजो दायकु फल चारि\n\nJaya Hanumana Gyana Guna Sagara\nJaya Kapeesa Tihun Loka Ujagara\n\nRama doot atulit bala dhama\nAnjani putra Pavana suta nama",
    festivals: ["Hanuman Jayanti", "Tuesdays & Saturdays", "Ram Navami"]
  },
  {
    id: "ganesha",
    name: "Ganesha",
    title: "The Remover of Obstacles",
    image: `${WP}/Ganesha_Basohli_miniature_circa_1730_Dubost_p73.jpg?width=500`,
    fallbackGradient: "from-amber-600 via-yellow-700 to-orange-800",
    glowColor: "rgba(245,158,11,0.5)",
    accentColor: "#fcd34d",
    description: "Ganesha is the most widely revered deity in Hinduism. As son of Shiva and Parvati, he is honoured at the beginning of all rituals and invoked before starting any new endeavour.",
    mythology: "Ganesha was created by Parvati from sandalwood paste. When Shiva returned and severed the boy's head, he replaced it with an elephant's head — and Ganesha was born anew.",
    attributes: ["Elephant Head", "Broken Tusk", "Modak (Sweet)", "Noose (Pasha)", "Goad (Ankusha)", "Mouse Mount"],
    mantra: "Om Gan Ganapataye Namaha",
    mantraFull: "ॐ गं गणपतये नमः\nOm Gan Ganapataye Namaha\n\nI bow to Ganapati (Ganesha).\nChanting before any beginning ensures success and removes obstacles.",
    festivals: ["Ganesh Chaturthi", "Vinayaka Chaturthi", "Sankashti Chaturthi"]
  },
  {
    id: "lakshmi",
    name: "Lakshmi",
    title: "Goddess of Wealth & Fortune",
    image: `${WP}/Lakshmi_by_Raja_Ravi_Varma.jpg?width=500`,
    fallbackGradient: "from-rose-600 via-pink-700 to-rose-900",
    glowColor: "rgba(244,114,182,0.5)",
    accentColor: "#f9a8d4",
    description: "Lakshmi is the Hindu goddess of wealth, fortune, prosperity, and beauty. She is the eternal consort of Vishnu who appeared from the cosmic ocean during the churning of the primordial sea.",
    mythology: "When the gods and demons churned the cosmic ocean (Samudra Manthan), Lakshmi arose from its depths seated on a lotus. She chose Vishnu as her eternal consort.",
    attributes: ["Lotus Flower", "Gold Coins", "Elephants", "Red & Pink Garments", "Owl (Vahana)", "Four Arms"],
    mantra: "Om Shreem Mahalakshmiyei Namaha",
    mantraFull: "ॐ श्रीं महालक्ष्म्यै नमः\nOm Shreem Mahalakshmiyei Namaha\n\nI bow to the great goddess Lakshmi.\nShreem is the bija mantra that attracts abundance into your life.",
    festivals: ["Diwali (Lakshmi Puja)", "Varalakshmi Vratam", "Kojagara Puja"]
  },
  {
    id: "saraswati",
    name: "Saraswati",
    title: "Goddess of Knowledge & Arts",
    image: `${WP}/Goddess_Saraswati_Devi.jpg?width=500`,
    fallbackGradient: "from-cyan-600 via-teal-700 to-cyan-900",
    glowColor: "rgba(34,211,238,0.45)",
    accentColor: "#67e8f9",
    description: "Saraswati is the divine embodiment of knowledge, learning, wisdom, music, arts, and speech. Revered by students, teachers, and artists seeking clarity and creative inspiration.",
    mythology: "Saraswati was born from Brahma's mind at the moment of creation. She is the mother of the Vedas and all forms of creative expression.",
    attributes: ["Veena (String Instrument)", "White Lotus", "Swan (Hamsa)", "Peacock", "Sacred Vedas", "White Garments"],
    mantra: "Saraswati Vandana",
    mantraFull: "या कुन्देन्दु तुषार हार धवला\nया शुभ्र वस्त्रावृता\nया वीणा वरदण्ड मण्डितकरा\nया श्वेत पद्मासना\n\nYa Kundendu Tushara Hara Dhavala\nShe who is white as the kunda flower and the moon",
    festivals: ["Vasant Panchami", "Saraswati Puja", "Navratri"]
  },
  {
    id: "parvati",
    name: "Parvati",
    title: "The Divine Mother",
    image: `${WP}/Parvati.jpg?width=500`,
    fallbackGradient: "from-pink-600 via-rose-700 to-fuchsia-800",
    glowColor: "rgba(236,72,153,0.45)",
    accentColor: "#f472b6",
    description: "Parvati is the Hindu goddess of love, fertility, beauty, and devotion. As the consort of Shiva and mother of Ganesha and Murugan, she is one of the central deities of the Shakti tradition.",
    mythology: "Parvati was reborn to win Shiva's love after her previous life as Sati. She performed severe austerities and tapas until Shiva accepted her. Together they are the cosmic couple symbolising Purusha and Prakriti.",
    attributes: ["Lotus", "Trident", "Conch", "Bell", "Tiger Mount", "Third Eye"],
    mantra: "Om Namah Parvatyai",
    mantraFull: "ॐ नमः पार्वत्यै\nOm Namah Parvatyai\nॐ उमायै नमः\nOm Umayai Namaha\n\nI bow to Goddess Parvati.\nShe who is the daughter of the mountain Himavan.",
    festivals: ["Teej", "Gauri Puja", "Navratri", "Hartalika Teej"]
  },
  {
    id: "durga",
    name: "Durga",
    title: "The Divine Warrior",
    image: `${WP}/Durga.jpg?width=500`,
    fallbackGradient: "from-red-600 via-rose-700 to-red-900",
    glowColor: "rgba(239,68,68,0.5)",
    accentColor: "#fca5a5",
    description: "Durga is the fierce and compassionate mother goddess who embodies the combined power (Shakti) of all the gods, representing invincible divine feminine energy.",
    mythology: "When the demon Mahishasura's boon made him invincible to all males, the gods combined their energies to create Durga. She battled the demon for nine days, finally slaying him on the tenth — Vijayadasami.",
    attributes: ["Lion/Tiger Mount", "Trident (Trishul)", "Sword (Khadga)", "Conch (Shankha)", "Bow and Arrow", "Ten Arms"],
    mantra: "Om Dum Durgayei Namaha",
    mantraFull: "ॐ दुं दुर्गायै नमः\nOm Dum Durgayei Namaha\n\nI bow to Goddess Durga.\nDum is the bija mantra invoking her protective power.",
    festivals: ["Navaratri", "Durga Puja", "Vijayadasami"]
  },
  {
    id: "kali",
    name: "Kali",
    title: "The Dark Mother",
    image: `${WP}/Kali_by_Raja_Ravi_Varma.jpg?width=500`,
    fallbackGradient: "from-purple-700 via-violet-900 to-gray-900",
    glowColor: "rgba(168,85,247,0.5)",
    accentColor: "#d8b4fe",
    description: "Kali is the fierce form of the Divine Mother, the goddess of time, change, and liberation. She destroys ego and evil, freeing devotees from the cycle of birth and death.",
    mythology: "Kali emerged from Durga's forehead during the battle with demons Chanda and Munda. Her dark form destroys all that is evil and illusory. She dances on Shiva, who lies beneath her feet.",
    attributes: ["Skull Garland", "Sword", "Severed Head", "Dark Blue/Black Skin", "Red Tongue", "Four Arms"],
    mantra: "Om Krim Kalyei Namaha",
    mantraFull: "ॐ क्रीं काल्यै नमः\nOm Krim Kalyei Namaha\n\nI bow to Goddess Kali.\nKrim is her bija mantra — the seed sound of transformation and liberation.",
    festivals: ["Kali Puja", "Navratri", "Shyama Puja"]
  },
  {
    id: "radha",
    name: "Radha",
    title: "The Beloved of Krishna",
    image: `${WP}/Radha_by_Raja_Ravi_Varma.jpg?width=500`,
    fallbackGradient: "from-fuchsia-600 via-pink-700 to-fuchsia-900",
    glowColor: "rgba(232,121,249,0.45)",
    accentColor: "#f0abfc",
    description: "Radha is the beloved consort and eternal companion of Krishna. In the Bhakti tradition, Radha represents the highest form of devotion — the soul's complete surrender to the Divine.",
    mythology: "Radha's love for Krishna is considered the purest form of divine love. Their love story in Vrindavan represents the eternal longing of the individual soul (Jiva) for union with the Supreme (Brahman).",
    attributes: ["Lotus Flower", "Flute", "Pink & Yellow Garments", "Peacock Feather", "Conch Bangles"],
    mantra: "Radhe Radhe",
    mantraFull: "राधे राधे\nRadhe Radhe\n\nRadhe Radhe Govinda\nRadhe Radhe Gopala\n\nThe simple chanting of Radha's name is said to purify the heart and awaken divine love.",
    festivals: ["Radha Ashtami", "Holi", "Yamuna Chhath"]
  },
  {
    id: "murugan",
    name: "Murugan",
    title: "The God of War & Wisdom",
    image: `${WP}/Murugan.jpg?width=500`,
    fallbackGradient: "from-teal-600 via-cyan-700 to-teal-900",
    glowColor: "rgba(20,184,166,0.5)",
    accentColor: "#5eead4",
    description: "Murugan (Kartikeya/Skanda) is the son of Shiva and Parvati, the god of war, victory, and wisdom. He is especially revered in South India and Sri Lanka.",
    mythology: "Murugan was born from six sparks of Shiva's third eye to lead the armies of the gods against the demon Tarakasura. He rides a peacock and carries the Vel (spear) given to him by Parvati.",
    attributes: ["Vel (Spear)", "Peacock Mount", "Rooster Flag", "Six Faces (Shanmukha)", "Red Garments"],
    mantra: "Om Saravana Bhava",
    mantraFull: "ॐ सरवण भव\nOm Saravana Bhava\n\nThe six-syllable mantra of Murugan.\nMurugan was raised by the six Krittika star-mothers in Saravana lake.",
    festivals: ["Thaipusam", "Panguni Uttiram", "Karthigai Deepam", "Skanda Sashti"]
  },
  {
    id: "surya",
    name: "Surya",
    title: "The Sun God",
    image: `${WP}/Surya.jpg?width=500`,
    fallbackGradient: "from-yellow-500 via-orange-600 to-yellow-800",
    glowColor: "rgba(234,179,8,0.6)",
    accentColor: "#fef08a",
    description: "Surya is the Hindu god of the Sun, the source of all life and light. He is one of the five principal deities (Panchayatana) and the visible form of the Brahman in the sky.",
    mythology: "Surya rides a golden chariot drawn by seven horses across the sky each day. He is the father of Karna, Yama, and Yamuna, and the teacher of Hanuman.",
    attributes: ["Golden Chariot", "Seven Horses", "Lotus Flowers", "Radiant Crown", "Bow and Arrow", "Two Hands"],
    mantra: "Om Suryaya Namaha",
    mantraFull: "ॐ सूर्याय नमः\nOm Suryaya Namaha\n\nGayatri Mantra to Surya:\nOm Bhur Bhuva Swaha\nTat Savitur Varenyam\nBhargo Devasya Dhimahi\nDhiyo Yo Nah Prachodayat",
    festivals: ["Chhath Puja", "Makar Sankranti", "Ratha Saptami"]
  },
  {
    id: "indra",
    name: "Indra",
    title: "King of the Gods",
    image: `${WP}/Indra.jpg?width=500`,
    fallbackGradient: "from-blue-600 via-indigo-700 to-blue-900",
    glowColor: "rgba(99,102,241,0.5)",
    accentColor: "#a5b4fc",
    description: "Indra is the king of the Devas (gods) and the ruler of Svarga (heaven). He is the god of lightning, thunder, storms, rains, and river flows.",
    mythology: "Indra wields the Vajra (thunderbolt) and commands the clouds. He defeated the serpent Vritra to release the cosmic waters. Though powerful, he has often been humbled by devotees' righteousness.",
    attributes: ["Vajra (Thunderbolt)", "Airavata (White Elephant)", "Ucchaishravas (White Horse)", "Crown", "Bow", "Net of Indra"],
    mantra: "Om Indraya Namaha",
    mantraFull: "ॐ इन्द्राय नमः\nOm Indraya Namaha\n\nI bow to Lord Indra, king of the gods.\nHe who brings rain and prosperity to the world.",
    festivals: ["Indra Puja", "Sakrendra Puja", "Monsoon rituals"]
  },
  {
    id: "agni",
    name: "Agni",
    title: "The God of Fire",
    image: `${WP}/Agni.jpg?width=500`,
    fallbackGradient: "from-red-500 via-orange-600 to-yellow-700",
    glowColor: "rgba(249,115,22,0.6)",
    accentColor: "#fed7aa",
    description: "Agni is the god of fire and the divine messenger who carries offerings from humans to the gods. He is present in every sacred fire ritual (Yajna) in Hinduism.",
    mythology: "Agni has two faces — one benevolent (carrying sacrificial offerings to the gods) and one malevolent. He lives in the fires of lightning, the hearth, and the sun.",
    attributes: ["Two Faces", "Ram Mount (Mesha)", "Seven Flames", "Sacrificial Spoon", "Flaming Hair", "Three Legs"],
    mantra: "Om Agnaye Namaha",
    mantraFull: "ॐ अग्नये नमः\nOm Agnaye Namaha\n\nAgni Suktam (Rigveda 1.1.1):\nAgnim ile purohitam\nYajnasya devam ritvijam\nHotaram ratna dhatamam",
    festivals: ["Every Yajna (fire ritual)", "Holi", "Karthigai Deepam"]
  },
  {
    id: "varuna",
    name: "Varuna",
    title: "The God of Cosmic Order",
    image: `${WP}/Varuna.jpg?width=500`,
    fallbackGradient: "from-blue-700 via-cyan-800 to-blue-900",
    glowColor: "rgba(6,182,212,0.45)",
    accentColor: "#67e8f9",
    description: "Varuna is the all-seeing god of water, oceans, and cosmic order (Rita). He is the upholder of divine law and the guardian of moral order in the universe.",
    mythology: "Varuna rides a sea creature (Makara) and carries a noose (Pasha) with which he binds the wicked. He knows all secrets and sees all actions through his thousand eyes (the stars).",
    attributes: ["Noose (Pasha)", "Sea Serpent Mount", "White Garments", "Thousand Eyes", "Water Vessel"],
    mantra: "Om Varunaya Namaha",
    mantraFull: "ॐ वरुणाय नमः\nOm Varunaya Namaha\n\nI bow to Lord Varuna.\nHe who upholds the cosmic law Rita and purifies all sins.",
    festivals: ["Narali Purnima", "Makara Sankranti", "Sea rituals"]
  },
  {
    id: "yama",
    name: "Yama",
    title: "The Lord of Death & Dharma",
    image: `${WP}/Yama.jpg?width=500`,
    fallbackGradient: "from-gray-700 via-green-900 to-gray-900",
    glowColor: "rgba(22,163,74,0.4)",
    accentColor: "#86efac",
    description: "Yama is the god of death, the lord of the underworld (Naraka), and the first mortal who died. He judges souls according to their deeds and administers divine justice.",
    mythology: "When a person dies, Yama's messengers bring the soul to his court, where the soul's deeds are read from Chitragupta's records and judgment is delivered.",
    attributes: ["Noose (Pasha)", "Mace (Danda)", "Buffalo Mount (Mahisha)", "Green Skin", "Red Garments", "Crown"],
    mantra: "Om Yamaya Namaha",
    mantraFull: "ॐ यमाय नमः\nOm Yamaya Namaha\n\nMrityunjaya Mantra (to overcome death):\nOm Tryambakam Yajamahe\nSugandhim Pushtivardhanam\nUrvarukamiva Bandhanan\nMrityor Mukshiya Mamritat",
    festivals: ["Yama Dwitiya (Bhai Dooj)", "Kartik Amavasya", "Chitragupta Puja"]
  },
  {
    id: "kubera",
    name: "Kubera",
    title: "The Lord of Wealth",
    image: `${WP}/Kubera.jpg?width=500`,
    fallbackGradient: "from-yellow-600 via-amber-700 to-yellow-900",
    glowColor: "rgba(251,191,36,0.5)",
    accentColor: "#fde68a",
    description: "Kubera is the god of wealth, prosperity, and the guardian of the North. He is the treasurer of the gods and king of the Yakshas (nature spirits).",
    mythology: "Kubera once lived in Lanka before Ravana conquered it. Brahma gave him immortality and made him the lord of all wealth. He rides the Pushpaka Vimana (flying chariot).",
    attributes: ["Money Bag (Nidhi)", "Mongoose", "Mace", "Pot-bellied Form", "Jewelled Crown", "Lotus"],
    mantra: "Om Shreem Hreem Kleem Shreem Kleem Vitteshvaraya Namaha",
    mantraFull: "ॐ श्रीं ह्रीं क्लीं श्रीं क्लीं वित्तेश्वराय नमः\nOm Shreem Hreem Kleem Shreem Kleem Vitteshvaraya Namaha\n\nI bow to Kubera, Lord of Wealth.\nChanting this mantra is said to attract abundance and prosperity.",
    festivals: ["Diwali", "Dhanteras", "Akshaya Tritiya"]
  }
];

// ── Quiz ────────────────────────────────────────────────────────────────────

export const quizQuestions = [
  { id: 1, question: "Which deity is known as the Destroyer in the Hindu trinity (Trimurti)?", options: ["Brahma", "Vishnu", "Shiva", "Indra"], correctAnswer: 2 },
  { id: 2, question: "The Bhagavad Gita is a part of which ancient Indian epic?", options: ["Ramayana", "Mahabharata", "Upanishads", "Vedas"], correctAnswer: 1 },
  { id: 3, question: "Which of the following is NOT one of the four Vedas?", options: ["Rigveda", "Samaveda", "Ayurveda", "Atharvaveda"], correctAnswer: 2 },
  { id: 4, question: "What does 'Moksha' signify in Hindu philosophy?", options: ["Good deeds", "Duty", "Cycle of rebirth", "Liberation from the cycle of rebirth"], correctAnswer: 3 },
  { id: 5, question: "Which festival celebrates the victory of light over darkness?", options: ["Holi", "Diwali", "Navaratri", "Makar Sankranti"], correctAnswer: 1 },
  { id: 6, question: "Who is the consort of Lord Vishnu and goddess of wealth?", options: ["Saraswati", "Parvati", "Lakshmi", "Durga"], correctAnswer: 2 },
  { id: 7, question: "The concept of 'Karma' translates most closely to:", options: ["Destiny", "Action and its consequence", "Devotion", "Knowledge"], correctAnswer: 1 },
  { id: 8, question: "Which river is considered the most sacred in Hinduism?", options: ["Yamuna", "Godavari", "Ganges (Ganga)", "Brahmaputra"], correctAnswer: 2 },
  { id: 9, question: "Holi is primarily associated with which deity?", options: ["Shiva", "Rama", "Krishna", "Ganesha"], correctAnswer: 2 },
  { id: 10, question: "What is the mount (vahana) of Lord Ganesha?", options: ["Peacock", "Mouse", "Bull", "Lion"], correctAnswer: 1 },
  { id: 11, question: "How many avatars (Dashavatara) does Vishnu traditionally have?", options: ["7", "8", "10", "12"], correctAnswer: 2 },
  { id: 12, question: "Which text contains 700 verses of dialogue between Krishna and Arjuna?", options: ["Rigveda", "Bhagavad Gita", "Ramayana", "Arthashastra"], correctAnswer: 1 },
  { id: 13, question: "Who is the father of Hanuman?", options: ["Brahma", "Vayu (Wind God)", "Indra", "Shiva"], correctAnswer: 1 },
  { id: 14, question: "Surya Puja is dedicated to which deity?", options: ["Agni", "Varuna", "Surya (Sun)", "Indra"], correctAnswer: 2 },
  { id: 15, question: "Which demon was slain by Durga?", options: ["Ravana", "Mahishasura", "Hiranyakashipu", "Tarakasura"], correctAnswer: 1 }
];

// ── Mantras ──────────────────────────────────────────────────────────────────

export const mantras = [
  { id: "gayatri", title: "Gayatri Mantra", deity: "Surya / Savitr", text: "Om Bhur Bhuva Swaha\nTat Savitur Varenyam\nBhargo Devasya Dhimahi\nDhiyo Yo Nah Prachodayat" },
  { id: "shivaya", title: "Panchakshari Mantra", deity: "Shiva", text: "Om Namah Shivaya\nॐ नमः शिवाय" },
  { id: "mrityunjaya", title: "Maha Mrityunjaya Mantra", deity: "Shiva", text: "Om Tryambakam Yajamahe\nSugandhim Pushtivardhanam\nUrvarukamiva Bandhanan\nMrityor Mukshiya Mamritat" },
  { id: "krishna", title: "Hare Krishna Mahamantra", deity: "Krishna", text: "Hare Krishna Hare Krishna\nKrishna Krishna Hare Hare\nHare Rama Hare Rama\nRama Rama Hare Hare" },
  { id: "ganesha", title: "Ganesha Moola Mantra", deity: "Ganesha", text: "Om Gan Ganapataye Namaha\nॐ गं गणपतये नमः" },
  { id: "lakshmi", title: "Mahalakshmi Mantra", deity: "Lakshmi", text: "Om Shreem Mahalakshmiyei Namaha\nॐ श्रीं महालक्ष्म्यै नमः" },
  { id: "saraswati", title: "Saraswati Vandana", deity: "Saraswati", text: "Ya Kundendu Tusharahara Dhavala\nYa Shubhra Vastravrita\nYa Veena Varadanda Manditakara\nYa Shveta Padmasana" },
  { id: "durga", title: "Durga Mantra", deity: "Durga", text: "Om Dum Durgayei Namaha\nॐ दुं दुर्गायै नमः" },
  { id: "hanuman", title: "Hanuman Mantra", deity: "Hanuman", text: "Om Hanumate Namaha\nॐ हनुमते नमः\n\nJaya Hanumana Gyana Guna Sagara" },
  { id: "rama", title: "Rama Taraka Mantra", deity: "Rama", text: "Sri Rama Rama Rameti\nRame Rame Manorame\nSahasranama Tattulyam\nRama Nama Varanane" },
  { id: "om", title: "Pranava Mantra", deity: "Brahman (Universal)", text: "ॐ\nAum\n\nThe primordial sound of the Universe" },
  { id: "kubera", title: "Kubera Mantra", deity: "Kubera", text: "Om Shreem Hreem Kleem\nVitteshvaraya Namaha\nॐ श्रीं ह्रीं क्लीं वित्तेश्वराय नमः" }
];

// ── Bhajans with Lyrics & verified YouTube IDs ───────────────────────────────
// YouTube IDs are for the most popular, long-standing devotional videos.
// The iframe will show "video unavailable" for any removed video instead of failing silently.

export const bhajans = [
  {
    id: "om-namah-shivaya",
    title: "Om Namah Shivaya",
    artist: "Shiva Bhajan",
    deity: "Shiva",
    image: `${WP}/Shiva_as_the_Lord_of_Dance_LACMA_edit.jpg?width=400`,
    youtubeId: "LHo5A-fXOKw",
    lyrics: `ॐ नमः शिवाय, ॐ नमः शिवाय
Om Namah Shivaya, Om Namah Shivaya

शिव शंकर को जिसने पूजा
उसका उद्धार हुआ
Shiva Shankara ko jisne pooja
Uska uddhaar hua

नाम शिव का जपते जपते
मन में प्रकाश हुआ
Naam Shiv ka japte japte
Man mein prakaash hua

ॐ नमः शिवाय... (repeat)

Na karo chinta duniya ki
Jo hai so Shiva ka hi hai
Bolo Om Namah Shivaya
Har har har Mahadeva!`
  },
  {
    id: "gayatri",
    title: "Gayatri Mantra",
    artist: "Vedic Chanting",
    deity: "Surya",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&q=80",
    youtubeId: "RiO58T6K80I",
    lyrics: `ॐ भूर्भुवः स्वः
Om Bhur Bhuva Swaha

तत् सवितुर् वरेण्यम्
Tat Savitur Varenyam

भर्गो देवस्य धीमहि
Bhargo Devasya Dhimahi

धियो यो नः प्रचोदयात्
Dhiyo Yo Nah Prachodayat

~ Meaning ~
We meditate on the glory of the Creator
who has created the Universe
who is worthy of worship
who is the embodiment of Knowledge and Light
who is the remover of all Sin and Ignorance
May He enlighten our intellect.`
  },
  {
    id: "hare-krishna",
    title: "Hare Krishna Maha Mantra",
    artist: "Krishna Kirtan",
    deity: "Krishna",
    image: `${WP}/Lord_Krishna_by_Raja_Ravi_Varma.jpg?width=400`,
    youtubeId: "UHnLSm6F-7E",
    lyrics: `हरे कृष्ण हरे कृष्ण
Hare Krishna Hare Krishna

कृष्ण कृष्ण हरे हरे
Krishna Krishna Hare Hare

हरे राम हरे राम
Hare Rama Hare Rama

राम राम हरे हरे
Rama Rama Hare Hare

~ Meaning ~
"Hare" calls to Radha, the energy of God.
"Krishna" is the all-attractive Supreme.
"Rama" is the reservoir of all pleasure.
This Mahamantra liberates the chanter
from material existence by awakening love of God.`
  },
  {
    id: "om-jai-jagdish",
    title: "Om Jai Jagdish Hare",
    artist: "Vishnu Aarti",
    deity: "Vishnu",
    image: "https://images.unsplash.com/photo-1548013146-72479768bada?w=400&q=80",
    youtubeId: "wYSBGJe8JDg",
    lyrics: `ॐ जय जगदीश हरे
Om Jai Jagdish Hare

स्वामी जय जगदीश हरे
Swami Jai Jagdish Hare

भक्त जनों के संकट
Bhakt janon ke sankat

दास जनों के संकट
Das janon ke sankat

क्षण में दूर करे
Kshan mein door kare

ॐ जय जगदीश हरे
Om Jai Jagdish Hare

~ Second Verse ~
Jo dhyaave phal paave
Dukh binase man ka
Sukh sampati ghar aave
Kasht mite tan ka`
  },
  {
    id: "saraswati-vandana",
    title: "Saraswati Vandana",
    artist: "Morning Prayer",
    deity: "Saraswati",
    image: `${WP}/Goddess_Saraswati_Devi.jpg?width=400`,
    youtubeId: "6RqOLKV3MBQ",
    lyrics: `या कुन्देन्दु तुषार हार धवला
Ya Kundendu Tushara Hara Dhavala

या शुभ्र वस्त्रावृता
Ya Shubhra Vastravrita

या वीणा वरदण्ड मण्डितकरा
Ya Veena Varadanda Manditakara

या श्वेत पद्मासना
Ya Shveta Padmasana

~ Meaning ~
She who is as white as the kunda flower,
the moon, the garland of ice, and snow,
She who is adorned in white garments,
She whose hands are decorated with the veena,
She who is seated on a white lotus —

सरस्वति नमस्तुभ्यम्
Saraswati Namastubhyam
Varade Kaama Roopini
Vidyaarambham Karishyaami
Siddhir Bhavantu Me Sada`
  },
  {
    id: "lakshmi-aarti",
    title: "Lakshmi Aarti",
    artist: "Diwali Aarti",
    deity: "Lakshmi",
    image: `${WP}/Lakshmi_by_Raja_Ravi_Varma.jpg?width=400`,
    youtubeId: "z_HUKpOxaFE",
    lyrics: `ॐ जय लक्ष्मी माता
Om Jai Lakshmi Mata

मैया जय लक्ष्मी माता
Maiya Jai Lakshmi Mata

तुमको निशदिन सेवत
Tumko nishadin sevat

हरि विष्णु विधाता
Hari Vishnu Vidhata

ॐ जय लक्ष्मी माता
Om Jai Lakshmi Mata

~ Second Verse ~
Uma Rama Brahmani
Tum hi Jagat Mata
Surya Chandrama dhyavet
Narad Rishi gaata`
  },
  {
    id: "hanuman-chalisa",
    title: "Hanuman Chalisa",
    artist: "Gulshan Kumar",
    deity: "Hanuman",
    image: "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=400&q=80",
    youtubeId: "AETFvQonfV8",
    lyrics: `श्री गुरु चरण सरोज रज
Shri Guru Charan Saroj Raj

निज मन मुकुरु सुधारि
Nij Manu Mukuru Sudhari

~ Doha ~
जय हनुमान ज्ञान गुण सागर
Jaya Hanumana Gyana Guna Sagara

जय कपीस तिहुँ लोक उजागर
Jaya Kapeesa Tihun Loka Ujagara

राम दूत अतुलित बल धामा
Rama Duta Atulit Bala Dhama

अञ्जनि-पुत्र पवनसुत नामा
Anjani-putra Pavana-suta Nama

~ Chaupai 1 ~
महाबीर बिक्रम बजरंगी
Mahavira Bikrama Bajarangi

कुमति निवार सुमति के संगी
Kumati Nivara Sumati Ke Sangi`
  },
  {
    id: "durga-stuti",
    title: "Durga Stuti",
    artist: "Navratri Bhajan",
    deity: "Durga",
    image: `${WP}/Durga.jpg?width=400`,
    youtubeId: "YgV_mGrF1gA",
    lyrics: `जय अम्बे गौरी
Jai Ambe Gauri

मैया जय श्यामा गौरी
Maiya Jai Shyama Gauri

ॐ जय अम्बे गौरी
Om Jai Ambe Gauri

~ Durga Shloka ~
सर्वमङ्गलमाङ्गल्ये शिवे सर्वार्थसाधिके
Sarva Mangala Mangalye Shive Sarvartha Sadhike

शरण्ये त्र्यम्बके गौरि नारायणि नमोऽस्तु ते
Sharanye Tryambake Gauri Narayani Namostute

Ya Devi sarva-bhuteshu shakti rupena samsthita
Namastasyai namastasyai namastasyai namo namah`
  },
  {
    id: "jai-shri-ram",
    title: "Jai Shri Ram",
    artist: "Ram Bhajan",
    deity: "Rama",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&q=80",
    youtubeId: "0_rlNTqBKHE",
    lyrics: `जय श्री राम, जय श्री राम
Jai Shri Ram, Jai Shri Ram

जय जय राम, जय जय राम
Jai Jai Ram, Jai Jai Ram

श्री राम राम रामेति
Sri Rama Rama Rameti

रमे रामे मनोरमे
Rame Rame Manorame

सहस्रनाम तत्तुल्यम्
Sahasranama Tattulyam

राम नाम वरानने
Rama Nama Varanane`
  },
  {
    id: "hymne-bhayangkara",
    title: "Hymne Bhayangkara",
    artist: "Polri / Indonesia",
    deity: "Patriotic",
    image: "https://images.unsplash.com/photo-1585468274952-66591eb14165?w=400&q=80",
    youtubeId: "C3Rl7zqnwlA",
    lyrics: `Kami Putra-putri Indonesia
Pewaris nilai-nilai luhur
Dengan jiwa Pancasila
Kami siap membangun nusa

Bhayangkara Indonesia
Abdi pertiwi yang setia
Pengayom masyarakat semesta
Penjaga keamanan bangsa

~ Reff ~
Bhayangkara! Bhayangkara!
Semangat Bhayangkara membara
Demi nusa dan bangsa
Kami berjuang selamanya

Teguh dalam pengabdian
Tulus dalam perjuangan
Kami Polri berdiri tegak
Melindungi NKRI`
  }
];
