import { useState, useEffect } from 'react';
import {
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  type User
} from 'firebase/auth';
import { auth, isDemoMode } from '../lib/firebase';

// ─── helpers ────────────────────────────────────────────────────────────────

function isMobileBrowser(): boolean {
  return (
    /iPhone|iPad|iPod|Android/i.test(navigator.userAgent) ||
    ('ontouchstart' in window && navigator.maxTouchPoints > 0)
  );
}

export function getFriendlyError(code: string): string {
  const hostname = typeof window !== 'undefined' ? window.location.hostname : 'this domain';
  const map: Record<string, string> = {
    'auth/popup-blocked':
      'Browser blocked the sign-in popup. Tap "Sign in" again — we\'ll redirect you instead.',
    'auth/popup-closed-by-user': 'Sign-in was cancelled.',
    'auth/cancelled-popup-request': 'Sign-in was cancelled.',
    'auth/network-request-failed':
      'Network error. Please check your connection and try again.',
    'auth/too-many-requests': 'Too many attempts. Please wait a moment and try again.',
    'auth/user-disabled': 'This Google account has been disabled.',
    'auth/account-exists-with-different-credential':
      'An account already exists with a different sign-in method.',
    'auth/unauthorized-domain':
      `UNAUTHORIZED_DOMAIN: "${hostname}" is not in Firebase's allowed list. ` +
      `Go to Firebase Console → Authentication → Settings → Authorized Domains → Add Domain → paste "${hostname}".`,
    'auth/internal-error': 'An internal error occurred. Please try again.',
    'auth/operation-not-allowed':
      'Google sign-in is not enabled. Go to Firebase Console → Authentication → Sign-in method → Enable Google.',
    'auth/invalid-api-key':
      'Invalid Firebase API key. Double-check VITE_FIREBASE_API_KEY in Replit Secrets.',
    'auth/app-not-authorized':
      'This app is not authorized to use Firebase Authentication. Check your Firebase project settings.',
  };
  return map[code] ?? `Sign-in failed (${code}). Please try again.`;
}

const REDIRECT_KEY = 'sd_auth_redirect_pending';

// ─── hook ────────────────────────────────────────────────────────────────────

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [redirectPending, setRedirectPending] = useState(
    () => sessionStorage.getItem(REDIRECT_KEY) === '1'
  );
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    // ── Demo mode ──────────────────────────────────────────────────────────
    if (isDemoMode) {
      try {
        const stored = localStorage.getItem('demo_user');
        if (stored) setUser(JSON.parse(stored));
      } catch {}
      setLoading(false);
      return;
    }

    // ── Real Firebase ──────────────────────────────────────────────────────
    // 1. Listen for auth state changes (handles persistence on page refresh)
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });

    // 2. Collect any pending redirect result (mobile sign-in returns here)
    if (sessionStorage.getItem(REDIRECT_KEY) === '1') {
      getRedirectResult(auth)
        .then((result) => {
          sessionStorage.removeItem(REDIRECT_KEY);
          setRedirectPending(false);
          if (result?.user) {
            setUser(result.user);
            setAuthError('');
          }
        })
        .catch((err: any) => {
          sessionStorage.removeItem(REDIRECT_KEY);
          setRedirectPending(false);
          if (err?.code && err.code !== 'auth/no-current-user') {
            setAuthError(getFriendlyError(err.code));
          }
        });
    }

    return () => unsubscribe();
  }, []);

  // ── signIn ─────────────────────────────────────────────────────────────────
  const signIn = async (): Promise<User | null> => {
    setAuthError('');

    // Demo mode — create a local fake user
    if (isDemoMode) {
      const demoUser = {
        uid: 'demo123',
        displayName: 'Demo Devotee',
        email: 'demo@sanatana.app',
        photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=om',
      } as unknown as User;
      localStorage.setItem('demo_user', JSON.stringify(demoUser));
      setUser(demoUser);
      return demoUser;
    }

    const provider = new GoogleAuthProvider();
    // Always ask which account to use, even if already signed in
    provider.setCustomParameters({ prompt: 'select_account' });

    // Mobile: redirect flow (popups are blocked by Android Chrome)
    if (isMobileBrowser()) {
      sessionStorage.setItem(REDIRECT_KEY, '1');
      setRedirectPending(true);
      await signInWithRedirect(auth, provider);
      return null; // page navigates away
    }

    // Desktop: popup first, fall back to redirect if blocked
    try {
      const result = await signInWithPopup(auth, provider);
      return result.user;
    } catch (err: any) {
      const code: string = err?.code ?? '';

      if (code === 'auth/popup-blocked' || code === 'auth/popup-closed-by-user') {
        // Silently fall back to redirect instead of throwing
        sessionStorage.setItem(REDIRECT_KEY, '1');
        setRedirectPending(true);
        await signInWithRedirect(auth, provider);
        return null;
      }

      const msg = getFriendlyError(code);
      setAuthError(msg);
      throw new Error(msg);
    }
  };

  // ── signOut ────────────────────────────────────────────────────────────────
  const signOut = async (): Promise<void> => {
    setAuthError('');
    if (isDemoMode) {
      localStorage.removeItem('demo_user');
      setUser(null);
      return;
    }
    await firebaseSignOut(auth);
  };

  return { user, loading, redirectPending, authError, signIn, signOut };
}
