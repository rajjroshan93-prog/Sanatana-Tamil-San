import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { deities } from '../data/content';
import { Link } from 'wouter';

function DeityCard({ deity, index }: { deity: typeof deities[0]; index: number }) {
  const [imgError, setImgError] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);

  return (
    <Link href={`/deity/${deity.id}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05, duration: 0.4 }}
        className="group rounded-2xl overflow-hidden cursor-pointer h-[360px] relative border transition-all duration-500"
        style={{
          borderColor: 'rgba(255,255,255,0.08)',
          background: 'rgba(255,255,255,0.03)',
        }}
        whileHover={{ scale: 1.02, borderColor: deity.accentColor + '50' }}
        data-testid={`deity-card-${deity.id}`}
      >
        {/* Background — gradient always visible, image overlaid on top */}
        <div className={`absolute inset-0 bg-gradient-to-br ${deity.fallbackGradient}`} />

        {/* Deity image */}
        {!imgError && (
          <img
            src={deity.image}
            alt={deity.name}
            className="absolute inset-0 w-full h-full object-cover object-top transition-all duration-700"
            style={{
              opacity: imgLoaded ? 0.85 : 0,
            }}
            onLoad={() => setImgLoaded(true)}
            onError={() => setImgError(true)}
          />
        )}

        {/* Hover brightness boost */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{ background: 'rgba(255,255,255,0.06)' }}
        />

        {/* Bottom gradient for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />

        {/* Deity glow on hover */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
          style={{ background: `radial-gradient(ellipse at 50% 100%, ${deity.glowColor} 0%, transparent 65%)` }}
        />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-5">
          <p
            className="text-[10px] font-cinzel tracking-[0.2em] uppercase mb-1.5 opacity-75"
            style={{ color: deity.accentColor }}
          >
            {deity.mantra}
          </p>
          <h3
            className="text-2xl font-cinzel font-bold mb-1 drop-shadow-lg"
            style={{ color: deity.accentColor }}
          >
            {deity.name}
          </h3>
          <p className="text-xs text-white/55 mb-2">{deity.title}</p>

          {/* Attributes preview on hover */}
          <div className="overflow-hidden max-h-0 group-hover:max-h-16 transition-all duration-400">
            <div className="flex flex-wrap gap-1 mt-1">
              {deity.attributes.slice(0, 3).map((a, i) => (
                <span key={i} className="text-[9px] px-2 py-0.5 rounded-full text-white/60"
                  style={{ background: `${deity.accentColor}18`, border: `1px solid ${deity.accentColor}30` }}>
                  {a}
                </span>
              ))}
            </div>
          </div>

          <div
            className="inline-flex items-center gap-1 mt-3 text-[11px] font-semibold opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-0 group-hover:translate-x-1"
            style={{ color: deity.accentColor }}
          >
            Explore deity →
          </div>
        </div>
      </motion.div>
    </Link>
  );
}

export default function Deities() {
  return (
    <div className="p-5 md:p-10 max-w-7xl mx-auto mt-16 md:mt-0 pb-24">
      <header className="mb-10">
        <p className="text-xs font-cinzel tracking-widest text-orange-400/60 uppercase mb-2">Sacred Pantheon</p>
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold mb-3"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Divine Pantheon
        </h1>
        <p className="text-white/50 max-w-2xl text-sm">
          Explore the 20 divine manifestations of the Supreme. Each deity represents a different aspect of ultimate reality, guiding devotees on their spiritual journey.
        </p>
      </header>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {deities.map((deity, index) => (
          <DeityCard key={deity.id} deity={deity} index={index} />
        ))}
      </div>

      <p className="text-center text-white/20 text-xs mt-10 font-cinzel tracking-wider">
        {deities.length} deities • Tap any card to explore
      </p>
    </div>
  );
}
