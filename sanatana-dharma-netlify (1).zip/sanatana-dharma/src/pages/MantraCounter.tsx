import React, { useState, useEffect, useRef } from 'react';
import { mantras } from '../data/content';

const TARGETS = [27, 54, 108, 216, 1008];
const STORAGE_KEY = 'mantra_progress';

interface MantraProgress {
  [mantraId: string]: number;
}

function loadProgress(): MantraProgress {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  } catch {
    return {};
  }
}

export default function MantraCounter() {
  const [selectedId, setSelectedId] = useState(mantras[0].id);
  const [target, setTarget] = useState(108);
  const [count, setCount] = useState(0);
  const [progress, setProgress] = useState<MantraProgress>(loadProgress());
  const [pulse, setPulse] = useState(false);
  const [completed, setCompleted] = useState(false);
  const touchRef = useRef<boolean>(false);

  const selected = mantras.find(m => m.id === selectedId)!;
  const pct = Math.min(100, (count / target) * 100);
  const totalAllTime = progress[selectedId] ?? 0;

  useEffect(() => {
    setCount(0);
    setCompleted(false);
  }, [selectedId, target]);

  const increment = () => {
    if (touchRef.current) return;
    const next = count + 1;
    setCount(next);
    setPulse(true);
    setTimeout(() => setPulse(false), 120);

    if (next >= target && !completed) {
      setCompleted(true);
      const updated = { ...progress, [selectedId]: totalAllTime + next };
      setProgress(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    }
  };

  const handleTouch = (e: React.TouchEvent) => {
    e.preventDefault();
    touchRef.current = true;
    const next = count + 1;
    setCount(next);
    setPulse(true);
    setTimeout(() => setPulse(false), 120);
    if (next >= target && !completed) {
      setCompleted(true);
      const updated = { ...progress, [selectedId]: totalAllTime + next };
      setProgress(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    }
    setTimeout(() => { touchRef.current = false; }, 50);
  };

  const reset = () => {
    setCount(0);
    setCompleted(false);
  };

  const beads = Array.from({ length: Math.min(108, target) });

  return (
    <div className="min-h-screen p-5 md:p-10 max-w-2xl mx-auto mt-16 md:mt-0 pb-32">
      {/* Header */}
      <header className="mb-8 text-center">
        <p className="text-xs font-cinzel tracking-widest text-orange-400/70 uppercase mb-2">Japa Mala</p>
        <h1 className="text-4xl font-cinzel font-bold mb-2"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Mantra Counter
        </h1>
        <p className="text-white/50 text-sm">Tap the Om symbol to count each repetition</p>
      </header>

      {/* Mantra selector */}
      <div className="mb-6">
        <label className="text-xs text-white/40 uppercase tracking-wider font-cinzel mb-2 block">Select Mantra</label>
        <select
          value={selectedId}
          onChange={e => setSelectedId(e.target.value)}
          className="w-full px-4 py-3 rounded-xl text-white text-sm font-medium focus:outline-none focus:ring-2 focus:ring-orange-500/40"
          style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)' }}
        >
          {mantras.map(m => (
            <option key={m.id} value={m.id} style={{ background: '#0f0e1a' }}>
              {m.title} — {m.deity}
            </option>
          ))}
        </select>
      </div>

      {/* Mantra text */}
      <div className="mb-6 p-4 rounded-xl text-center"
        style={{ background: 'rgba(255,107,53,0.06)', border: '1px solid rgba(255,107,53,0.15)' }}>
        <p className="text-orange-300/80 text-sm font-cinzel leading-relaxed whitespace-pre-line">{selected.text}</p>
      </div>

      {/* Target selector */}
      <div className="mb-8 flex gap-2 flex-wrap justify-center">
        {TARGETS.map(t => (
          <button
            key={t}
            onClick={() => setTarget(t)}
            className={`px-4 py-2 rounded-full text-sm font-bold transition-all ${target === t ? 'text-white shadow-lg' : 'text-white/40 hover:text-white/70'}`}
            style={target === t ? { background: 'linear-gradient(135deg,#FF6B35,#7B2FBE)' } : { background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Progress ring + tap button */}
      <div className="flex flex-col items-center mb-8">
        <div className="relative mb-6" style={{ width: 220, height: 220 }}>
          {/* SVG ring */}
          <svg className="absolute inset-0" viewBox="0 0 220 220" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx="110" cy="110" r="96" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
            <circle
              cx="110" cy="110" r="96" fill="none"
              stroke="url(#grad)" strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 96}`}
              strokeDashoffset={`${2 * Math.PI * 96 * (1 - pct / 100)}`}
              style={{ transition: 'stroke-dashoffset 0.3s ease' }}
            />
            <defs>
              <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FF6B35" />
                <stop offset="100%" stopColor="#FFD700" />
              </linearGradient>
            </defs>
          </svg>

          {/* Tap button */}
          <button
            onClick={increment}
            onTouchStart={handleTouch}
            className={`absolute inset-4 rounded-full flex flex-col items-center justify-center select-none transition-all duration-100 active:scale-95 ${pulse ? 'scale-95' : 'scale-100'}`}
            style={{
              background: completed
                ? 'linear-gradient(135deg,#22c55e,#16a34a)'
                : 'linear-gradient(135deg,rgba(255,107,53,0.15),rgba(123,47,190,0.15))',
              border: `2px solid ${completed ? 'rgba(34,197,94,0.5)' : 'rgba(255,107,53,0.3)'}`,
              boxShadow: pulse ? '0 0 40px rgba(255,107,53,0.5)' : '0 0 20px rgba(255,107,53,0.15)',
              cursor: 'pointer',
              WebkitTapHighlightColor: 'transparent',
              touchAction: 'manipulation',
            }}
            aria-label="Count mantra"
          >
            <span className="text-5xl font-cinzel" style={{ color: '#FFD700', lineHeight: 1 }}>ॐ</span>
            <span className="text-3xl font-bold text-white mt-1">{count}</span>
            <span className="text-xs text-white/40 mt-1">of {target}</span>
          </button>
        </div>

        {/* Completion message */}
        {completed && (
          <div className="mb-4 px-6 py-3 rounded-full text-sm font-semibold text-green-300"
            style={{ background: 'rgba(34,197,94,0.12)', border: '1px solid rgba(34,197,94,0.3)' }}>
            🎉 Japa complete! {target} repetitions done.
          </div>
        )}

        {/* Controls */}
        <div className="flex gap-3">
          <button onClick={reset}
            className="px-5 py-2.5 rounded-xl text-sm text-white/60 hover:text-white transition-colors"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            Reset
          </button>
          <button
            onClick={() => {
              if (!completed) {
                const updated = { ...progress, [selectedId]: totalAllTime + count };
                setProgress(updated);
                localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
              }
            }}
            className="px-5 py-2.5 rounded-xl text-sm text-white transition-colors"
            style={{ background: 'rgba(255,107,53,0.15)', border: '1px solid rgba(255,107,53,0.3)' }}>
            Save Progress
          </button>
        </div>
      </div>

      {/* Bead visualiser */}
      <div className="mb-6">
        <p className="text-xs text-white/30 uppercase tracking-wider font-cinzel mb-3 text-center">Mala Beads</p>
        <div className="flex flex-wrap justify-center gap-1.5">
          {beads.map((_, i) => (
            <div key={i}
              className="rounded-full transition-all duration-200"
              style={{
                width: 10, height: 10,
                background: i < count ? 'linear-gradient(135deg,#FF6B35,#FFD700)' : 'rgba(255,255,255,0.08)',
                boxShadow: i < count ? '0 0 4px rgba(255,107,53,0.4)' : 'none',
              }} />
          ))}
        </div>
      </div>

      {/* All-time total */}
      <div className="text-center mt-4">
        <p className="text-xs text-white/30">
          All-time total for <span className="text-orange-400/70">{selected.title}</span>:{' '}
          <span className="text-white/60 font-bold">{totalAllTime.toLocaleString()}</span> repetitions
        </p>
      </div>
    </div>
  );
}
