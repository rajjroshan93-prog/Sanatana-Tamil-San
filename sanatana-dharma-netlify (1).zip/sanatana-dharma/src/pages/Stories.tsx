import React, { useState } from 'react';
import { sacredStories, type SacredStory } from '../data/stories';

const CATEGORY_LABEL: Record<SacredStory['category'], string> = {
  creation: 'Creation', avatar: 'Avatar', devotion: 'Devotion', wisdom: 'Wisdom', battle: 'Battle'
};
const CATEGORY_COLOR: Record<SacredStory['category'], string> = {
  creation: '#fbbf24', avatar: '#34d399', devotion: '#f472b6', wisdom: '#818cf8', battle: '#f87171'
};

function StoryCard({ story, onClick }: { story: SacredStory; onClick: () => void }) {
  const [imgErr, setImgErr] = useState(false);
  const color = CATEGORY_COLOR[story.category];
  return (
    <button onClick={onClick}
      className="text-left group rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] active:scale-95 w-full"
      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
      {/* Image */}
      <div className="relative h-36 overflow-hidden">
        {!imgErr ? (
          <img src={story.image} alt={story.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-500"
            onError={() => setImgErr(true)} />
        ) : (
          <div className="w-full h-full" style={{ background: `linear-gradient(135deg, ${story.gradientFrom}, ${story.gradientTo})` }} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
        <span className="absolute top-3 left-3 text-xs px-2.5 py-1 rounded-full font-semibold"
          style={{ background: `${color}25`, border: `1px solid ${color}40`, color }}>
          {CATEGORY_LABEL[story.category]}
        </span>
      </div>
      {/* Content */}
      <div className="p-4">
        <p className="text-xs text-white/40 font-cinzel uppercase tracking-wider mb-1">{story.deity}</p>
        <h3 className="text-base font-cinzel font-bold text-white mb-1 group-hover:text-orange-300 transition-colors">{story.title}</h3>
        <p className="text-xs text-white/40 mb-2 italic">{story.subtitle}</p>
        <p className="text-xs text-white/55 leading-relaxed line-clamp-2">{story.summary}</p>
        <span className="text-xs mt-3 inline-flex items-center gap-1 font-medium" style={{ color }}>
          Read story →
        </span>
      </div>
    </button>
  );
}

function StoryReader({ story, onClose }: { story: SacredStory; onClose: () => void }) {
  const [imgErr, setImgErr] = useState(false);
  const color = CATEGORY_COLOR[story.category];
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" style={{ background: '#0a091a' }}>
      {/* Hero */}
      <div className="relative h-52 md:h-72">
        {!imgErr ? (
          <img src={story.image} alt={story.title} className="w-full h-full object-cover opacity-40"
            onError={() => setImgErr(true)} />
        ) : (
          <div className="w-full h-full" style={{ background: `linear-gradient(135deg, ${story.gradientFrom}, ${story.gradientTo})` }} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a091a] via-transparent to-black/40" />
        <button onClick={onClose}
          className="absolute top-4 left-4 p-2 rounded-xl text-white/60 hover:text-white transition-colors"
          style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)' }}>
          ← Back
        </button>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-6 pb-24 -mt-8 relative">
        <span className="text-xs px-3 py-1 rounded-full font-semibold inline-block mb-4"
          style={{ background: `${color}20`, border: `1px solid ${color}35`, color }}>
          {CATEGORY_LABEL[story.category]} • {story.deity}
        </span>
        <h1 className="text-3xl md:text-4xl font-cinzel font-bold text-white mb-2">{story.title}</h1>
        <p className="text-white/50 italic mb-8">{story.subtitle}</p>

        {/* Story text */}
        <div className="prose prose-invert max-w-none">
          {story.story.split('\n\n').map((para, i) => (
            <p key={i} className="text-white/70 leading-relaxed mb-5 text-sm md:text-base"
              style={para.startsWith('•') ? { paddingLeft: '1rem' } : {}}>
              {para}
            </p>
          ))}
        </div>

        {/* Moral */}
        <div className="mt-8 p-5 rounded-2xl"
          style={{ background: `${color}10`, border: `1px solid ${color}25` }}>
          <p className="text-xs font-cinzel uppercase tracking-wider mb-2" style={{ color }}>Moral of the Story</p>
          <p className="text-sm text-white/65 leading-relaxed italic">{story.moral}</p>
        </div>

        {/* Source */}
        <p className="text-xs text-white/25 text-center mt-6">
          Source: <span className="text-white/40">{story.source}</span>
        </p>
      </div>
    </div>
  );
}

export default function Stories() {
  const [reading, setReading] = useState<SacredStory | null>(null);
  const [filter, setFilter] = useState<SacredStory['category'] | 'all'>('all');

  const categories: Array<SacredStory['category'] | 'all'> = ['all','creation','avatar','devotion','wisdom','battle'];
  const filtered = filter === 'all' ? sacredStories : sacredStories.filter(s => s.category === filter);

  if (reading) return <StoryReader story={reading} onClose={() => setReading(null)} />;

  return (
    <div className="p-5 md:p-10 max-w-6xl mx-auto mt-16 md:mt-0 pb-32">
      <header className="mb-8">
        <p className="text-xs font-cinzel tracking-widest text-orange-400/70 uppercase mb-2">Puranic Katha</p>
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold mb-2"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Sacred Stories
        </h1>
        <p className="text-white/50 text-sm max-w-xl">
          Ancient tales from the Puranas, Ramayana, Mahabharata, and Upanishads — the living heart of Sanatana Dharma.
        </p>
      </header>

      {/* Category filter */}
      <div className="flex gap-2 flex-wrap mb-8">
        {categories.map(cat => (
          <button key={cat} onClick={() => setFilter(cat)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold capitalize transition-all ${filter === cat ? 'text-white shadow-lg' : 'text-white/40 hover:text-white/70'}`}
            style={filter === cat
              ? { background: cat === 'all' ? 'linear-gradient(135deg,#FF6B35,#7B2FBE)' : `${CATEGORY_COLOR[cat as SacredStory['category']]}90`, border: '1px solid transparent' }
              : { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}>
            {cat === 'all' ? 'All Stories' : CATEGORY_LABEL[cat as SacredStory['category']]}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map(story => (
          <StoryCard key={story.id} story={story} onClick={() => setReading(story)} />
        ))}
      </div>
    </div>
  );
}
