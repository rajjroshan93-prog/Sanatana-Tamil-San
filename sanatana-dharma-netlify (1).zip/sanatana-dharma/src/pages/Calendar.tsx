import React, { useState } from 'react';
import { hinduFestivals, getUpcomingFestivals, getDaysUntil, fastingDays, type HinduFestival } from '../data/calendar';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const TYPE_COLORS: Record<HinduFestival['type'], string> = {
  major:   'bg-amber-500/20 text-amber-300 border-amber-500/30',
  minor:   'bg-blue-500/20 text-blue-300 border-blue-500/30',
  fasting: 'bg-violet-500/20 text-violet-300 border-violet-500/30',
  puja:    'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
};
const TYPE_LABEL: Record<HinduFestival['type'], string> = {
  major: 'Major Festival', minor: 'Minor Festival', fasting: 'Fasting Day', puja: 'Puja'
};

function FestivalBadge({ type }: { type: HinduFestival['type'] }) {
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${TYPE_COLORS[type]}`}>
      {TYPE_LABEL[type]}
    </span>
  );
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
}

export default function Calendar() {
  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth());
  const [selected, setSelected] = useState<HinduFestival | null>(null);

  const upcoming = getUpcomingFestivals(6);

  const monthFestivals = hinduFestivals.filter(f => {
    const d = new Date(f.date);
    return d.getFullYear() === viewYear && d.getMonth() === viewMonth;
  });

  const prevMonth = () => {
    if (viewMonth === 0) { setViewYear(y => y - 1); setViewMonth(11); }
    else setViewMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (viewMonth === 11) { setViewYear(y => y + 1); setViewMonth(0); }
    else setViewMonth(m => m + 1);
  };

  // Build calendar grid
  const firstDay = new Date(viewYear, viewMonth, 1).getDay();
  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const cells: (number | null)[] = [
    ...Array(firstDay).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1)
  ];
  const festivalDates = new Set(
    monthFestivals.map(f => new Date(f.date).getDate())
  );
  const todayDate = today.getFullYear() === viewYear && today.getMonth() === viewMonth ? today.getDate() : null;

  return (
    <div className="p-5 md:p-10 max-w-5xl mx-auto mt-16 md:mt-0 pb-32">
      {/* Header */}
      <header className="mb-8">
        <p className="text-xs font-cinzel tracking-widest text-orange-400/70 uppercase mb-2">Panchang</p>
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold mb-2"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Hindu Calendar
        </h1>
        <p className="text-white/50 text-sm">Festival dates, fasting days, and sacred occasions for 2025–2026</p>
      </header>

      {/* Upcoming festivals strip */}
      <section className="mb-10">
        <h2 className="text-sm font-cinzel text-white/50 uppercase tracking-wider mb-4">Upcoming Festivals</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {upcoming.map(f => {
            const days = getDaysUntil(f.date);
            return (
              <button key={f.id} onClick={() => setSelected(f)}
                className="text-left p-4 rounded-2xl transition-all hover:scale-[1.02] active:scale-95"
                style={{ background: `linear-gradient(135deg, ${f.color}18, rgba(255,255,255,0.03))`, border: `1px solid ${f.color}30` }}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: f.color }} />
                  <FestivalBadge type={f.type} />
                </div>
                <p className="font-bold text-white text-sm leading-tight mb-1">{f.name}</p>
                <p className="text-xs text-white/40">{formatDate(f.date)}</p>
                <p className="text-xs mt-1 font-semibold" style={{ color: f.color }}>
                  {days === 0 ? '🎉 Today!' : days === 1 ? 'Tomorrow' : `In ${days} days`}
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Month calendar */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-6">
          <button onClick={prevMonth} className="p-2 rounded-xl text-white/50 hover:text-white transition-colors"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            ←
          </button>
          <h2 className="text-xl font-cinzel font-bold text-white">{MONTHS[viewMonth]} {viewYear}</h2>
          <button onClick={nextMonth} className="p-2 rounded-xl text-white/50 hover:text-white transition-colors"
            style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            →
          </button>
        </div>

        <div className="rounded-2xl overflow-hidden" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
          {/* Day labels */}
          <div className="grid grid-cols-7 text-center">
            {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
              <div key={d} className="py-2 text-xs font-cinzel text-white/30 uppercase tracking-wider">{d}</div>
            ))}
          </div>
          {/* Cells */}
          <div className="grid grid-cols-7">
            {cells.map((day, i) => {
              const hasFestival = day && festivalDates.has(day);
              const isToday = day === todayDate;
              const festival = hasFestival ? monthFestivals.find(f => new Date(f.date).getDate() === day) : null;
              return (
                <div key={i}
                  onClick={() => festival && setSelected(festival)}
                  className={`relative min-h-[52px] border-t border-white/5 flex flex-col items-center pt-2 transition-colors
                    ${hasFestival ? 'cursor-pointer hover:bg-white/5' : ''}
                    ${isToday ? 'bg-orange-500/10' : ''}
                  `}>
                  {day && (
                    <>
                      <span className={`text-sm leading-none mb-1 ${isToday ? 'text-orange-400 font-bold' : 'text-white/60'}`}>
                        {day}
                      </span>
                      {festival && (
                        <span className="w-5 h-1 rounded-full" style={{ background: festival.color }} />
                      )}
                      {festival && (
                        <span className="text-[9px] text-white/40 text-center px-0.5 leading-tight mt-0.5 hidden sm:block truncate w-full text-center">
                          {festival.name}
                        </span>
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Month festival list */}
        {monthFestivals.length > 0 && (
          <div className="mt-4 space-y-2">
            {monthFestivals.map(f => (
              <button key={f.id} onClick={() => setSelected(f)}
                className="w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all hover:bg-white/5"
                style={{ border: '1px solid rgba(255,255,255,0.06)' }}>
                <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: f.color }} />
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-semibold text-white">{f.name}</span>
                  {f.deity && <span className="text-xs text-white/40 ml-2">• {f.deity}</span>}
                </div>
                <span className="text-xs text-white/30 flex-shrink-0">{new Date(f.date).getDate()} {MONTHS[new Date(f.date).getMonth()]}</span>
                <FestivalBadge type={f.type} />
              </button>
            ))}
          </div>
        )}
        {monthFestivals.length === 0 && (
          <p className="text-center text-white/30 text-sm mt-4">No festivals this month in the calendar.</p>
        )}
      </section>

      {/* Fasting days */}
      <section className="mb-8">
        <h2 className="text-sm font-cinzel text-white/50 uppercase tracking-wider mb-4">Regular Fasting Days</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {fastingDays.map((d, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl"
              style={{ background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.15)' }}>
              <span className="text-violet-400">🌙</span>
              <span className="text-sm text-white/60">{d}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Festival detail modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(8px)' }}
          onClick={() => setSelected(null)}>
          <div className="w-full max-w-md rounded-3xl p-6 relative"
            style={{ background: '#0f0e1a', border: `1px solid ${selected.color}40` }}
            onClick={e => e.stopPropagation()}>
            <div className="flex items-start gap-3 mb-4">
              <span className="w-3 h-3 rounded-full mt-1.5 flex-shrink-0" style={{ background: selected.color }} />
              <div>
                <h3 className="text-xl font-cinzel font-bold text-white mb-1">{selected.name}</h3>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm text-white/40">{formatDate(selected.date)}</span>
                  <FestivalBadge type={selected.type} />
                </div>
              </div>
            </div>
            {selected.deity && (
              <p className="text-xs text-orange-400/70 font-cinzel mb-2 uppercase tracking-wider">Deity: {selected.deity}</p>
            )}
            <p className="text-sm text-white/60 leading-relaxed mb-5">{selected.description}</p>
            <button onClick={() => setSelected(null)}
              className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all"
              style={{ background: `linear-gradient(135deg, ${selected.color}40, rgba(255,255,255,0.05))`, border: `1px solid ${selected.color}30` }}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
