import React, { useState, useEffect } from 'react';
import { bhajans } from '../data/content';
import { useBhajanPlayer } from '../hooks/use-bhajan-player';
import { Play, Pause, Music, FileText, X } from 'lucide-react';

export default function Bhajans() {
  const { currentBhajan, isPlaying, play, pause, resume, setPlaylist } = useBhajanPlayer();
  const [lyricsId, setLyricsId] = useState<string | null>(null);

  useEffect(() => { setPlaylist(bhajans); }, [setPlaylist]);

  // Auto-show lyrics when song starts playing
  useEffect(() => {
    if (currentBhajan && isPlaying) setLyricsId(currentBhajan.id);
  }, [currentBhajan?.id]);

  const lyricsFor = bhajans.find(b => b.id === lyricsId);

  return (
    <div className="p-5 md:p-10 max-w-5xl mx-auto mt-16 md:mt-0 pb-48 md:pb-28">
      <header className="mb-8 text-center md:text-left">
        <div className="flex items-center gap-3 mb-3 justify-center md:justify-start">
          <Music size={18} className="text-orange-400" />
          <span className="text-xs font-cinzel tracking-widest text-white/40 uppercase">Sacred Sound</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-cinzel font-bold mb-2"
          style={{ background: 'linear-gradient(90deg,#FF6B35,#FFD700)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          Bhajan Mandal
        </h1>
        <p className="text-white/50 text-sm max-w-xl">
          Devotional bhajans and kirtans with full lyrics. Tap a card to play — lyrics appear automatically.
        </p>
      </header>

      {/* Lyrics panel */}
      {lyricsFor && (
        <div className="mb-8 rounded-2xl overflow-hidden relative"
          style={{ background: 'linear-gradient(135deg,rgba(255,107,53,0.06),rgba(123,47,190,0.06))', border: '1px solid rgba(255,107,53,0.2)' }}>
          <div className="flex items-center justify-between px-5 pt-4 pb-2 border-b border-white/6">
            <div>
              <p className="text-xs text-orange-400/70 font-cinzel uppercase tracking-wider">Now Playing — Lyrics</p>
              <h3 className="text-base font-cinzel font-bold text-white mt-0.5">{lyricsFor.title}</h3>
              <p className="text-xs text-white/40">{lyricsFor.deity} • {lyricsFor.artist}</p>
            </div>
            <button onClick={() => setLyricsId(null)} className="p-1.5 text-white/30 hover:text-white rounded-lg transition-colors">
              <X size={16} />
            </button>
          </div>
          <div className="px-5 py-4 max-h-56 overflow-y-auto">
            <pre className="text-sm text-white/65 font-sans leading-relaxed whitespace-pre-wrap">
              {lyricsFor.lyrics}
            </pre>
          </div>
        </div>
      )}

      {/* Bhajan grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {bhajans.map((bhajan) => {
          const isCurrent = currentBhajan?.id === bhajan.id;
          const isLyricsOpen = lyricsId === bhajan.id;
          const hasLyrics = !!bhajan.lyrics;

          return (
            <div
              key={bhajan.id}
              className={`glass-panel rounded-2xl overflow-hidden group border transition-all duration-300 ${
                isCurrent
                  ? 'border-orange-500/50 shadow-[0_0_24px_rgba(255,107,53,0.12)]'
                  : 'border-white/8 hover:border-orange-500/25'
              }`}
            >
              {/* Image */}
              <div
                className="relative h-40 w-full overflow-hidden cursor-pointer"
                onClick={() => {
                  if (isCurrent && isPlaying) pause();
                  else if (isCurrent) resume();
                  else play(bhajan, bhajans);
                }}
              >
                <img
                  src={bhajan.image}
                  alt={bhajan.title}
                  className={`w-full h-full object-cover object-top transition-transform duration-700 ${isCurrent ? 'scale-105' : 'group-hover:scale-105'}`}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />

                {/* Play overlay */}
                <div className={`absolute inset-0 flex items-center justify-center transition-opacity ${isCurrent ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-xl transition-all ${isCurrent && isPlaying ? 'bg-orange-500' : 'bg-white/20 backdrop-blur-md'}`}>
                    {isCurrent && isPlaying
                      ? <Pause size={18} fill="white" className="text-white" />
                      : <Play size={18} fill="white" className="text-white ml-0.5" />}
                  </div>
                </div>

                {/* Deity tag */}
                <div className="absolute top-2.5 right-2.5">
                  <span className="text-xs px-2 py-0.5 rounded-full text-white/80 font-medium"
                    style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)' }}>
                    {bhajan.deity}
                  </span>
                </div>

                {/* Playing bars */}
                {isCurrent && isPlaying && (
                  <div className="absolute bottom-2.5 left-3 flex items-end gap-0.5 h-4">
                    {[0.7, 0.4, 0.9, 0.5].map((_, idx) => (
                      <div key={idx} className="w-0.5 bg-orange-400 rounded-t animate-bounce"
                        style={{ height: `${[12,8,14,10][idx]}px`, animationDelay: `${idx * 80}ms` }} />
                    ))}
                  </div>
                )}
              </div>

              {/* Info + lyrics toggle */}
              <div className="p-3.5 flex items-center gap-3">
                <div className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => {
                    if (isCurrent && isPlaying) pause();
                    else if (isCurrent) resume();
                    else play(bhajan, bhajans);
                  }}>
                  <h3 className="font-bold text-sm text-white truncate font-cinzel">{bhajan.title}</h3>
                  <p className="text-xs text-white/40 mt-0.5">{bhajan.artist}</p>
                </div>

                {hasLyrics && (
                  <button
                    onClick={() => setLyricsId(isLyricsOpen ? null : bhajan.id)}
                    className={`flex-shrink-0 p-1.5 rounded-lg transition-all ${isLyricsOpen ? 'text-orange-400 bg-orange-500/15' : 'text-white/30 hover:text-white/70 hover:bg-white/8'}`}
                    title="Show lyrics"
                  >
                    <FileText size={14} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-xs text-white/25 text-center mt-8">
        Audio streams from the Internet Archive. If a track does not play, the player will offer a YouTube fallback automatically.
      </p>
    </div>
  );
}
