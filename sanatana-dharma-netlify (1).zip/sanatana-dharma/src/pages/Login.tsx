import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/use-auth';
import { useLocation } from 'wouter';
import { isDemoMode } from '../lib/firebase';

// The domain this app is running on — must be added to Firebase Authorized Domains
const THIS_DOMAIN = typeof window !== 'undefined' ? window.location.hostname : '';

export default function Login() {
  const { user, loading, redirectPending, authError, signIn } = useAuth();
  const [, setLocation] = useLocation();
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState('');
  const [success, setSuccess] = useState(false);

  // Redirect once signed in — never call navigation during render
  useEffect(() => {
    if (user && !loading) {
      setSuccess(true);
      const t = setTimeout(() => setLocation('/dashboard'), 700);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [user, loading]);

  const handleLogin = async () => {
    setBusy(true);
    setLocalError('');
    try {
      await signIn();
      // Mobile redirect: page navigates away, nothing more to do here.
      // Popup / demo: onAuthStateChanged fires and updates user state.
    } catch (err: any) {
      setLocalError(err?.message ?? 'Sign-in failed. Please try again.');
      setBusy(false);
    }
  };

  const errorMsg = localError || authError;
  const isUnauthorizedDomain = errorMsg.includes('UNAUTHORIZED_DOMAIN') || errorMsg.includes('unauthorized-domain');
  const isOperationNotAllowed = errorMsg.includes('not enabled') || errorMsg.includes('operation-not-allowed');

  // While redirect is returning from Google (page just reloaded with auth code)
  if (redirectPending) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background">
        <span className="text-4xl font-cinzel" style={{ color: '#FFD700' }}>ॐ</span>
        <p className="text-white/60 text-sm animate-pulse">Completing Google sign-in…</p>
        <span className="w-6 h-6 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // Brief success flash before redirect
  if (success) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 bg-background">
        <span className="text-4xl" style={{ color: '#FFD700' }}>ॐ</span>
        <p className="text-green-400 text-sm font-semibold">Welcome! Entering sanctuary…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden py-8">
      <div className="absolute inset-0 bg-background" />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at 50% 40%, rgba(123,47,190,0.12) 0%, transparent 60%)' }}
      />

      <div className="glass-panel p-7 rounded-3xl max-w-sm w-full mx-4 z-10 text-center relative overflow-hidden">
        {/* Top gradient bar */}
        <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-primary via-violet-500 to-amber-400" />

        {/* Om symbol */}
        <div
          className="text-6xl mb-4 font-cinzel"
          style={{ color: '#FFD700', textShadow: '0 0 30px rgba(255,215,0,0.35)' }}
        >
          ॐ
        </div>

        <h2 className="text-2xl font-cinzel font-bold text-foreground mb-1.5">Sacred Entrance</h2>
        <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
          Sign in to save your spiritual progress, earn XP, and track your devotion journey.
        </p>

        {/* ── Demo mode notice ─────────────────────────────────────────────── */}
        {isDemoMode && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-400/80 text-left leading-relaxed space-y-1">
            <p><span className="font-semibold text-amber-400">Demo Mode</span> — No Firebase keys detected.</p>
            <p>Progress is saved locally in this browser.</p>
            <p className="mt-1 text-amber-500/60">
              Add <code className="text-amber-300/80">VITE_FIREBASE_*</code> secrets in Replit to enable real Google Sign-In.
            </p>
          </div>
        )}

        {/* ── Generic error ────────────────────────────────────────────────── */}
        {errorMsg && !isUnauthorizedDomain && !isOperationNotAllowed && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400/90 text-left leading-relaxed">
            ⚠️ {errorMsg}
          </div>
        )}

        {/* ── Unauthorized domain — show exact fix steps ───────────────────── */}
        {isUnauthorizedDomain && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-left leading-relaxed space-y-2">
            <p className="text-red-400 font-semibold">⚠️ Domain not authorized in Firebase</p>
            <p className="text-white/50">This domain must be added to your Firebase project:</p>
            <code className="block bg-black/30 rounded px-2 py-1.5 text-amber-300 text-xs break-all select-all">
              {THIS_DOMAIN}
            </code>
            <ol className="text-white/50 space-y-1 list-decimal list-inside">
              <li>Open <span className="text-white/70">Firebase Console</span></li>
              <li>Go to <span className="text-white/70">Authentication → Settings</span></li>
              <li>Click <span className="text-white/70">Authorized Domains → Add domain</span></li>
              <li>Paste the domain above and save</li>
            </ol>
          </div>
        )}

        {/* ── Google Sign-In not enabled ───────────────────────────────────── */}
        {isOperationNotAllowed && (
          <div className="mb-5 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-left leading-relaxed space-y-2">
            <p className="text-red-400 font-semibold">⚠️ Google Sign-In not enabled</p>
            <ol className="text-white/50 space-y-1 list-decimal list-inside">
              <li>Open <span className="text-white/70">Firebase Console</span></li>
              <li>Go to <span className="text-white/70">Authentication → Sign-in method</span></li>
              <li>Enable <span className="text-white/70">Google</span> and save</li>
            </ol>
          </div>
        )}

        {/* ── Google login button ──────────────────────────────────────────── */}
        <button
          onClick={handleLogin}
          disabled={busy || loading}
          className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-xl font-medium text-foreground transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,107,53,0.3)',
          }}
          data-testid="button-google-login"
        >
          {busy ? (
            <span className="w-5 h-5 border-2 border-primary/40 border-t-primary rounded-full animate-spin flex-shrink-0" />
          ) : (
            <img
              src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
              alt=""
              className="w-5 h-5 flex-shrink-0 bg-white rounded-full p-0.5"
            />
          )}
          <span>
            {busy
              ? 'Redirecting to Google…'
              : isDemoMode
              ? 'Continue as Demo Devotee'
              : 'Continue with Google'}
          </span>
        </button>

        {/* Mobile hint — only shown in real Firebase mode with no errors */}
        {!isDemoMode && !errorMsg && (
          <p className="mt-4 text-xs text-muted-foreground/45 leading-relaxed">
            On mobile you'll be redirected to Google and returned here automatically.
          </p>
        )}

        {/* ── Firebase setup checklist (real mode, no error yet) ───────────── */}
        {!isDemoMode && !errorMsg && THIS_DOMAIN && (
          <div className="mt-5 pt-4 border-t border-white/6 text-left space-y-2">
            <p className="text-xs text-white/30 font-medium uppercase tracking-wider">Firebase setup checklist</p>
            <ul className="text-xs text-white/40 space-y-1">
              <li>✓ VITE_FIREBASE_* secrets configured</li>
              <li className="text-amber-400/70">
                → Authorized Domain: <code className="text-amber-300/70 break-all">{THIS_DOMAIN}</code>
              </li>
              <li className="text-white/30">→ Google Sign-In enabled in Firebase Console</li>
            </ul>
          </div>
        )}

        <div className="mt-5 pt-4 border-t border-card-border/20 text-xs text-muted-foreground/30">
          By entering, you honor the sacred space of this digital sanctuary.
        </div>
      </div>
    </div>
  );
}
